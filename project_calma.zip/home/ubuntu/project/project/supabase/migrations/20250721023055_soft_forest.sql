/*
  # Atualizar conteúdo completo do livro

  1. Conteúdo Completo
    - Adiciona todo o conteúdo dos 9 capítulos do livro Calma
    - Conteúdo rico em técnicas de mindfulness e relaxamento
    - Formatação HTML para melhor apresentação

  2. Estrutura
    - Mantém a estrutura existente da tabela
    - Atualiza apenas o conteúdo dos capítulos
    - Preserva metadados e timestamps
*/

-- Atualizar capítulo 1
UPDATE book_chapters SET 
title = 'Introdução ao Mindfulness',
content = '<h2>Bem-vindo à Jornada da Calma</h2>

<p>O mindfulness, ou atenção plena, é uma prática milenar que nos convida a estar completamente presentes no momento atual. Em um mundo cada vez mais acelerado e cheio de distrações, essa habilidade se torna não apenas valiosa, mas essencial para nosso bem-estar mental e emocional.</p>

<h3>O que é Mindfulness?</h3>

<p>Mindfulness é a capacidade de prestar atenção ao momento presente de forma intencional e sem julgamento. É observar nossos pensamentos, sentimentos e sensações corporais como eles são, sem tentar mudá-los ou resistir a eles.</p>

<p>Esta prática nos ensina a:</p>
<ul>
<li>Reconhecer padrões mentais automáticos</li>
<li>Desenvolver maior consciência emocional</li>
<li>Reduzir o estresse e a ansiedade</li>
<li>Melhorar a concentração e foco</li>
<li>Cultivar compaixão por nós mesmos e outros</li>
</ul>

<h3>Por que Praticar?</h3>

<p>Pesquisas científicas demonstram que a prática regular de mindfulness pode:</p>
<ul>
<li>Reduzir os níveis de cortisol (hormônio do estresse)</li>
<li>Melhorar a qualidade do sono</li>
<li>Fortalecer o sistema imunológico</li>
<li>Aumentar a neuroplasticidade cerebral</li>
<li>Promover maior estabilidade emocional</li>
</ul>

<h3>Como Começar</h3>

<p>A jornada do mindfulness começa com pequenos passos. Não é necessário meditar por horas ou alcançar um estado de "mente vazia". Comece com apenas alguns minutos por dia, observando sua respiração ou prestando atenção plena a atividades cotidianas como comer ou caminhar.</p>

<p>Lembre-se: mindfulness é uma prática, não uma perfeição. Cada momento de consciência é uma vitória, independentemente de quão breve seja.</p>'
WHERE chapter = 1;

-- Atualizar capítulo 2
UPDATE book_chapters SET 
title = 'A Respiração Consciente',
content = '<h2>O Poder da Respiração</h2>

<p>A respiração é nossa companheira constante, presente desde o primeiro até o último momento de nossas vidas. Embora seja um processo automático, quando trazemos consciência para ela, a respiração se torna uma ferramenta poderosa de transformação e cura.</p>

<h3>Por que a Respiração é Especial?</h3>

<p>A respiração é única porque é tanto voluntária quanto involuntária. Podemos controlá-la conscientemente, mas ela também acontece automaticamente. Esta característica a torna uma ponte perfeita entre nossa mente consciente e nosso sistema nervoso autônomo.</p>

<h3>Técnicas Fundamentais</h3>

<h4>1. Respiração Abdominal</h4>
<p>Coloque uma mão no peito e outra no abdômen. Respire de forma que apenas a mão do abdômen se mova. Esta técnica ativa o sistema nervoso parassimpático, promovendo relaxamento.</p>

<h4>2. Respiração 4-7-8</h4>
<p>Inspire por 4 tempos, segure por 7, expire por 8. Esta técnica é especialmente eficaz para reduzir ansiedade e promover o sono.</p>

<h4>3. Respiração Quadrada (Box Breathing)</h4>
<p>Inspire por 4, segure por 4, expire por 4, pausa por 4. Excelente para melhorar concentração e equilíbrio emocional.</p>

<h3>Benefícios Científicos</h3>

<p>A respiração consciente demonstrou:</p>
<ul>
<li>Reduzir a pressão arterial</li>
<li>Diminuir os níveis de ansiedade</li>
<li>Melhorar a variabilidade da frequência cardíaca</li>
<li>Aumentar a oxigenação cerebral</li>
<li>Promover clareza mental</li>
</ul>

<h3>Prática Diária</h3>

<p>Comece com 5 minutos diários de respiração consciente. Escolha um horário fixo - muitas pessoas preferem logo ao acordar ou antes de dormir. Gradualmente, você pode aumentar o tempo conforme se sentir confortável.</p>

<p>Lembre-se: não existe respiração "errada". Se sua mente divagar, simplesmente retorne gentilmente à respiração. Esta é a essência da prática.</p>'
WHERE chapter = 2;

-- Atualizar capítulo 3
UPDATE book_chapters SET 
title = 'Meditação para Iniciantes',
content = '<h2>Primeiros Passos na Meditação</h2>

<p>A meditação é frequentemente envolvida em mistério e conceitos complexos, mas na realidade, é uma prática simples e acessível a todos. Não requer equipamentos especiais, locais exóticos ou habilidades sobrenaturais - apenas sua disposição para estar presente.</p>

<h3>Desmistificando a Meditação</h3>

<p>Muitas pessoas acreditam que meditar significa "esvaziar a mente" ou parar completamente os pensamentos. Esta é uma concepção equivocada que pode desencorajar iniciantes. A meditação é sobre observar os pensamentos sem se envolver com eles, como nuvens passando no céu.</p>

<h3>Preparando o Ambiente</h3>

<h4>Local</h4>
<ul>
<li>Escolha um espaço silencioso e confortável</li>
<li>Não precisa ser grande - um canto do quarto é suficiente</li>
<li>Mantenha a temperatura agradável</li>
<li>Desligue dispositivos eletrônicos</li>
</ul>

<h4>Postura</h4>
<ul>
<li>Sente-se com a coluna ereta, mas não rígida</li>
<li>Pode ser em uma cadeira, almofada ou banco de meditação</li>
<li>Relaxe os ombros</li>
<li>Feche os olhos suavemente ou mantenha um olhar suave</li>
</ul>

<h3>Técnicas para Iniciantes</h3>

<h4>1. Meditação da Respiração</h4>
<p>Foque sua atenção na respiração natural. Quando a mente divagar (e ela vai!), gentilmente retorne à respiração. Comece com 5-10 minutos.</p>

<h4>2. Body Scan (Varredura Corporal)</h4>
<p>Direcione sua atenção para diferentes partes do corpo, começando pelos pés e subindo até a cabeça. Observe sensações sem tentar mudá-las.</p>

<h4>3. Meditação com Mantras</h4>
<p>Repita uma palavra ou frase significativa, como "paz", "calma" ou "eu estou presente". O som ajuda a manter o foco.</p>

<h3>Lidando com Desafios Comuns</h3>

<h4>Mente Agitada</h4>
<p>É normal! Não lute contra os pensamentos. Reconheça-os e gentilmente retorne ao foco escolhido.</p>

<h4>Desconforto Físico</h4>
<p>Ajuste sua postura conforme necessário. Conforto é importante para manter a prática.</p>

<h4>Sonolência</h4>
<p>Pode indicar que você precisa de mais descanso. Tente meditar em um horário diferente ou com os olhos ligeiramente abertos.</p>

<h3>Construindo uma Prática Sustentável</h3>

<p>Consistência é mais importante que duração. É melhor meditar 5 minutos todos os dias do que 30 minutos uma vez por semana. Comece pequeno e aumente gradualmente.</p>

<p>Seja paciente consigo mesmo. A meditação é uma habilidade que se desenvolve com o tempo. Cada sessão é valiosa, independentemente de como você se sinta durante ela.</p>'
WHERE chapter = 3;

-- Atualizar capítulo 4
UPDATE book_chapters SET 
title = 'Técnicas de Relaxamento Corporal',
content = '<h2>Liberando Tensões do Corpo</h2>

<p>Nosso corpo carrega as tensões e estresses do dia a dia, muitas vezes sem que percebamos. Músculos contraídos, ombros tensos e mandíbula cerrada são sinais de que precisamos de técnicas específicas para liberar essas tensões acumuladas.</p>

<h3>A Conexão Mente-Corpo</h3>

<p>O corpo e a mente estão intrinsecamente conectados. Quando relaxamos o corpo, a mente naturalmente segue, e vice-versa. Esta conexão é a base de todas as técnicas de relaxamento corporal.</p>

<h3>Relaxamento Muscular Progressivo</h3>

<p>Desenvolvida por Edmund Jacobson, esta técnica envolve tensionar e relaxar grupos musculares específicos:</p>

<h4>Sequência Básica:</h4>
<ol>
<li><strong>Pés e Panturrilhas:</strong> Contraia por 5 segundos, relaxe por 10</li>
<li><strong>Coxas e Glúteos:</strong> Tensione e solte</li>
<li><strong>Abdômen:</strong> Contraia os músculos abdominais</li>
<li><strong>Mãos e Braços:</strong> Feche os punhos, tensione os braços</li>
<li><strong>Ombros e Pescoço:</strong> Levante os ombros em direção às orelhas</li>
<li><strong>Face:</strong> Franza a testa, feche os olhos firmemente</li>
</ol>

<h3>Técnica do Body Scan</h3>

<p>Esta prática envolve "escanear" mentalmente todo o corpo:</p>

<ol>
<li>Deite-se confortavelmente</li>
<li>Comece pelos dedos dos pés</li>
<li>Mova lentamente sua atenção pelo corpo</li>
<li>Observe sensações sem tentar mudá-las</li>
<li>Termine no topo da cabeça</li>
</ol>

<h3>Automassagem Relaxante</h3>

<h4>Pontos-Chave para Massagear:</h4>
<ul>
<li><strong>Têmporas:</strong> Movimentos circulares suaves</li>
<li><strong>Base do crânio:</strong> Pressão gentil com os dedos</li>
<li><strong>Ombros:</strong> Amasse suavemente os músculos</li>
<li><strong>Mãos:</strong> Massageie as palmas e dedos</li>
<li><strong>Pés:</strong> Pressione pontos na sola dos pés</li>
</ul>

<h3>Respiração para Relaxamento</h3>

<h4>Respiração Abdominal Profunda:</h4>
<p>Coloque uma mão no peito e outra no abdômen. Respire de forma que apenas a mão do abdômen se mova. Esta técnica ativa o sistema nervoso parassimpático.</p>

<h4>Respiração 4-7-8 para Relaxamento:</h4>
<ul>
<li>Inspire pelo nariz por 4 tempos</li>
<li>Segure a respiração por 7 tempos</li>
<li>Expire pela boca por 8 tempos</li>
<li>Repita 4-8 ciclos</li>
</ul>

<h3>Alongamentos Relaxantes</h3>

<h4>Sequência Simples:</h4>
<ol>
<li><strong>Pescoço:</strong> Gire suavemente para ambos os lados</li>
<li><strong>Ombros:</strong> Role para frente e para trás</li>
<li><strong>Braços:</strong> Estique acima da cabeça</li>
<li><strong>Coluna:</strong> Torção suave sentado</li>
<li><strong>Pernas:</strong> Alongue os isquiotibiais</li>
</ol>

<h3>Criando uma Rotina</h3>

<p>Estabeleça uma rotina de relaxamento corporal:</p>
<ul>
<li><strong>Manhã:</strong> Alongamentos suaves para despertar</li>
<li><strong>Meio do dia:</strong> Relaxamento muscular rápido</li>
<li><strong>Noite:</strong> Body scan completo antes de dormir</li>
</ul>

<p>Lembre-se: o relaxamento corporal é uma habilidade que melhora com a prática. Seja paciente e gentil consigo mesmo durante o processo.</p>'
WHERE chapter = 4;

-- Atualizar capítulo 5
UPDATE book_chapters SET 
title = 'Mindfulness no Dia a Dia',
content = '<h2>Integrando a Consciência Plena na Vida Cotidiana</h2>

<p>O verdadeiro poder do mindfulness se revela quando conseguimos integrá-lo em nossas atividades diárias. Não precisamos de momentos especiais ou ambientes perfeitos - cada momento da vida oferece uma oportunidade para praticar a atenção plena.</p>

<h3>Mindfulness nas Atividades Rotineiras</h3>

<h4>Comer Consciente</h4>
<p>Transforme as refeições em momentos de meditação:</p>
<ul>
<li>Observe as cores, texturas e aromas da comida</li>
<li>Mastigue lentamente, saboreando cada mordida</li>
<li>Note as sensações de fome e saciedade</li>
<li>Evite distrações como TV ou celular</li>
<li>Agradeça pela refeição</li>
</ul>

<h4>Caminhar Meditativo</h4>
<p>Cada passo pode ser uma oportunidade de presença:</p>
<ul>
<li>Sinta os pés tocando o chão</li>
<li>Observe o movimento das pernas</li>
<li>Note os sons ao redor</li>
<li>Respire em sincronia com os passos</li>
<li>Mantenha um ritmo mais lento que o habitual</li>
</ul>

<h4>Tarefas Domésticas Conscientes</h4>
<p>Transforme atividades mundanas em práticas de mindfulness:</p>
<ul>
<li><strong>Lavar louça:</strong> Sinta a temperatura da água, a textura dos objetos</li>
<li><strong>Varrer:</strong> Observe o movimento rítmico, o som da vassoura</li>
<li><strong>Dobrar roupas:</strong> Note as texturas, cores e movimentos das mãos</li>
</ul>

<h3>Mindfulness no Trabalho</h3>

<h4>Pausas Conscientes</h4>
<p>Incorpore micro-meditações durante o dia:</p>
<ul>
<li><strong>Respiração de 3 minutos:</strong> Entre reuniões ou tarefas</li>
<li><strong>Alongamento consciente:</strong> Observe as sensações corporais</li>
<li><strong>Caminhada até o banheiro:</strong> Use como momento de presença</li>
</ul>

<h4>Comunicação Mindful</h4>
<p>Pratique escuta ativa e fala consciente:</p>
<ul>
<li>Ouça completamente antes de responder</li>
<li>Note suas reações emocionais</li>
<li>Respire antes de falar</li>
<li>Escolha palavras com intenção</li>
<li>Mantenha contato visual</li>
</ul>

<h3>Lidando com Emoções Difíceis</h3>

<h4>Técnica RAIN</h4>
<p>Uma abordagem mindful para emoções desafiadoras:</p>
<ul>
<li><strong>R - Reconhecer:</strong> "Estou sentindo raiva"</li>
<li><strong>A - Aceitar:</strong> "É normal sentir isso"</li>
<li><strong>I - Investigar:</strong> "Onde sinto isso no corpo?"</li>
<li><strong>N - Não-identificação:</strong> "Eu não sou essa emoção"</li>
</ul>

<h4>Espaço de Respiração</h4>
<p>Quando se sentir sobrecarregado:</p>
<ol>
<li><strong>Pare:</strong> Interrompa o que está fazendo</li>
<li><strong>Respire:</strong> Três respirações profundas</li>
<li><strong>Observe:</strong> O que está acontecendo agora?</li>
<li><strong>Proceda:</strong> Continue com maior consciência</li>
</ol>

<h3>Mindfulness Digital</h3>

<h4>Uso Consciente da Tecnologia</h4>
<ul>
<li>Pause antes de pegar o celular</li>
<li>Defina horários específicos para redes sociais</li>
<li>Pratique "jejum digital" regularmente</li>
<li>Use apps de mindfulness como lembretes</li>
<li>Crie espaços livres de tecnologia em casa</li>
</ul>

<h3>Relacionamentos Conscientes</h3>

<h4>Presença com Entes Queridos</h4>
<ul>
<li>Dê atenção total quando alguém estiver falando</li>
<li>Note julgamentos que surgem</li>
<li>Pratique compaixão ativa</li>
<li>Respire antes de reagir em conflitos</li>
<li>Expresse gratidão regularmente</li>
</ul>

<h3>Criando Âncoras de Mindfulness</h3>

<p>Estabeleça lembretes naturais para voltar ao presente:</p>
<ul>
<li><strong>Toques de sino:</strong> Use como sinal para respirar</li>
<li><strong>Semáforos:</strong> Momentos para verificar sua respiração</li>
<li><strong>Portas:</strong> Pause antes de atravessar</li>
<li><strong>Notificações:</strong> Transforme em lembretes de presença</li>
</ul>

<p>Lembre-se: mindfulness no dia a dia não é sobre perfeição, mas sobre retornar repetidamente ao momento presente com gentileza e curiosidade.</p>'
WHERE chapter = 5;

-- Atualizar capítulo 6
UPDATE book_chapters SET 
title = 'Gerenciando Ansiedade e Estresse',
content = '<h2>Transformando a Relação com Ansiedade e Estresse</h2>

<p>A ansiedade e o estresse são experiências humanas universais. Em doses moderadas, podem até ser úteis, nos alertando para perigos ou nos motivando para ação. No entanto, quando se tornam crônicos ou excessivos, podem prejudicar significativamente nossa qualidade de vida.</p>

<h3>Compreendendo a Ansiedade</h3>

<p>A ansiedade é uma resposta natural do corpo a situações percebidas como ameaçadoras. Ela ativa nosso sistema nervoso simpático, preparando-nos para "lutar ou fugir". Os sintomas incluem:</p>

<ul>
<li>Coração acelerado</li>
<li>Respiração superficial</li>
<li>Tensão muscular</li>
<li>Pensamentos acelerados</li>
<li>Sensação de inquietação</li>
</ul>

<h3>O Ciclo do Estresse</h3>

<p>O estresse crônico cria um ciclo vicioso:</p>
<ol>
<li><strong>Gatilho:</strong> Situação estressante</li>
<li><strong>Pensamento:</strong> Interpretação negativa</li>
<li><strong>Emoção:</strong> Ansiedade, medo, frustração</li>
<li><strong>Comportamento:</strong> Evitação ou reação excessiva</li>
<li><strong>Consequência:</strong> Reforço do padrão</li>
</ol>

<h3>Técnicas de Respiração para Ansiedade</h3>

<h4>Respiração 4-7-8 (Técnica do Dr. Andrew Weil)</h4>
<p>Especialmente eficaz para ansiedade aguda:</p>
<ol>
<li>Expire completamente pela boca</li>
<li>Feche a boca, inspire pelo nariz por 4 tempos</li>
<li>Segure a respiração por 7 tempos</li>
<li>Expire pela boca por 8 tempos</li>
<li>Repita 4 ciclos</li>
</ol>

<h4>Respiração Quadrada</h4>
<p>Para equilibrar o sistema nervoso:</p>
<ul>
<li>Inspire por 4 tempos</li>
<li>Segure por 4 tempos</li>
<li>Expire por 4 tempos</li>
<li>Pause por 4 tempos</li>
</ul>

<h3>Técnicas de Grounding (Ancoragem)</h3>

<h4>Técnica 5-4-3-2-1</h4>
<p>Para momentos de ansiedade intensa:</p>
<ul>
<li><strong>5 coisas</strong> que você pode VER</li>
<li><strong>4 coisas</strong> que você pode TOCAR</li>
<li><strong>3 coisas</strong> que você pode OUVIR</li>
<li><strong>2 coisas</strong> que você pode CHEIRAR</li>
<li><strong>1 coisa</strong> que você pode SABOREAR</li>
</ul>

<h4>Ancoragem Física</h4>
<ul>
<li>Pressione os pés firmemente no chão</li>
<li>Segure um objeto com textura</li>
<li>Lave o rosto com água fria</li>
<li>Faça automassagem nas mãos</li>
</ul>

<h3>Reestruturação Cognitiva</h3>

<h4>Questionando Pensamentos Ansiosos</h4>
<p>Quando um pensamento ansioso surgir, pergunte:</p>
<ul>
<li>Este pensamento é realista?</li>
<li>Qual é a evidência para e contra?</li>
<li>Qual seria o pior cenário real?</li>
<li>Como eu lidaria se isso acontecesse?</li>
<li>O que eu diria a um amigo nesta situação?</li>
</ul>

<h4>Técnica do "E se... então..."</h4>
<p>Planeje respostas para cenários temidos:</p>
<ul>
<li>"E se eu ficar nervoso na apresentação... então vou respirar fundo e continuar"</li>
<li>"E se eu não conseguir dormir... então vou praticar relaxamento"</li>
</ul>

<h3>Práticas de Mindfulness para Ansiedade</h3>

<h4>Observação sem Julgamento</h4>
<p>Quando a ansiedade surgir:</p>
<ol>
<li>Reconheça: "Ansiedade está presente"</li>
<li>Observe onde sente no corpo</li>
<li>Respire com a sensação</li>
<li>Lembre-se: "Isso vai passar"</li>
</ol>

<h4>Meditação RAIN para Ansiedade</h4>
<ul>
<li><strong>Reconhecer:</strong> "Estou ansioso"</li>
<li><strong>Aceitar:</strong> "É normal sentir ansiedade"</li>
<li><strong>Investigar:</strong> "Como isso se manifesta no meu corpo?"</li>
<li><strong>Não-identificação:</strong> "Eu não sou minha ansiedade"</li>
</ul>

<h3>Estratégias de Longo Prazo</h3>

<h4>Higiene do Sono</h4>
<ul>
<li>Horários regulares para dormir e acordar</li>
<li>Evite cafeína após 14h</li>
<li>Crie um ritual relaxante antes de dormir</li>
<li>Mantenha o quarto fresco e escuro</li>
</ul>

<h4>Exercício Regular</h4>
<ul>
<li>Caminhadas diárias de 20-30 minutos</li>
<li>Yoga ou tai chi</li>
<li>Qualquer atividade que você goste</li>
<li>Exercícios de força moderados</li>
</ul>

<h4>Nutrição para o Bem-estar Mental</h4>
<ul>
<li>Reduza açúcar e cafeína</li>
<li>Aumente ômega-3 (peixes, nozes)</li>
<li>Mantenha-se hidratado</li>
<li>Evite álcool em excesso</li>
</ul>

<h3>Quando Buscar Ajuda Profissional</h3>

<p>Procure um profissional se:</p>
<ul>
<li>A ansiedade interfere nas atividades diárias</li>
<li>Você evita situações importantes</li>
<li>Tem ataques de pânico frequentes</li>
<li>Sente-se deprimido ou desesperançoso</li>
<li>Usa substâncias para lidar com a ansiedade</li>
</ul>

<p>Lembre-se: buscar ajuda é um sinal de força, não de fraqueza. Você merece viver uma vida plena e tranquila.</p>'
WHERE chapter = 6;

-- Atualizar capítulo 7
UPDATE book_chapters SET 
title = 'Cultivando Compaixão e Autocompaixão',
content = '<h2>O Poder Transformador da Compaixão</h2>

<p>A compaixão é uma das qualidades mais poderosas que podemos cultivar. Ela não apenas transforma nossos relacionamentos com outros, mas fundamentalmente muda nossa relação conosco mesmos. A autocompaixão, em particular, é um antídoto poderoso contra a autocrítica e o perfeccionismo que tanto nos fazem sofrer.</p>

<h3>Compreendendo a Compaixão</h3>

<p>Compaixão não é pena ou simpatia. É a capacidade de reconhecer o sofrimento - nosso ou de outros - e responder com bondade e desejo de ajudar. Segundo a pesquisadora Kristin Neff, a autocompaixão tem três componentes:</p>

<ol>
<li><strong>Bondade consigo mesmo:</strong> Tratar-se com gentileza em momentos difíceis</li>
<li><strong>Humanidade comum:</strong> Reconhecer que o sofrimento faz parte da experiência humana</li>
<li><strong>Mindfulness:</strong> Observar pensamentos e sentimentos sem se identificar com eles</li>
</ol>

<h3>Os Benefícios da Autocompaixão</h3>

<p>Pesquisas mostram que a autocompaixão está associada a:</p>
<ul>
<li>Menor ansiedade e depressão</li>
<li>Maior motivação e resiliência</li>
<li>Melhor qualidade nos relacionamentos</li>
<li>Maior satisfação com a vida</li>
<li>Melhor saúde física</li>
<li>Maior criatividade e aprendizado</li>
</ul>

<h3>Práticas de Autocompaixão</h3>

<h4>Meditação Loving-Kindness (Metta)</h4>
<p>Comece enviando amor para si mesmo:</p>
<ol>
<li>Sente-se confortavelmente e feche os olhos</li>
<li>Coloque as mãos no coração</li>
<li>Repita mentalmente:
   <ul>
   <li>"Que eu seja feliz"</li>
   <li>"Que eu seja saudável"</li>
   <li>"Que eu esteja em paz"</li>
   <li>"Que eu viva com facilidade"</li>
   </ul>
</li>
<li>Estenda para entes queridos, pessoas neutras, pessoas difíceis</li>
<li>Termine enviando para todos os seres</li>
</ol>

<h4>Carta de Autocompaixão</h4>
<p>Quando enfrentar dificuldades:</p>
<ol>
<li>Escreva sobre a situação que está causando sofrimento</li>
<li>Reconheça que o sofrimento é parte da vida humana</li>
<li>Escreva para si mesmo como escreveria para um amigo querido</li>
<li>Ofereça palavras de compreensão e encorajamento</li>
<li>Releia quando precisar de apoio</li>
</ol>

<h4>Toque Autocompassivo</h4>
<p>Use o toque físico para se acalmar:</p>
<ul>
<li>Coloque a mão no coração</li>
<li>Abrace-se gentilmente</li>
<li>Massageie as mãos ou braços</li>
<li>Toque o rosto com ternura</li>
</ul>

<h3>Lidando com a Autocrítica</h3>

<h4>Reconhecendo o Crítico Interno</h4>
<p>Observe quando sua voz interna se torna crítica:</p>
<ul>
<li>Que tom ela usa?</li>
<li>Que palavras escolhe?</li>
<li>Como isso afeta seu corpo?</li>
<li>Como isso afeta suas emoções?</li>
</ul>

<h4>Transformando a Autocrítica</h4>
<p>Quando notar autocrítica:</p>
<ol>
<li><strong>Pause:</strong> "Estou sendo crítico comigo"</li>
<li><strong>Reconheça:</strong> "Isso é sofrimento"</li>
<li><strong>Ofereça compaixão:</strong> "Que eu seja gentil comigo"</li>
<li><strong>Reformule:</strong> "Como posso aprender com isso?"</li>
</ol>

<h3>Compaixão pelos Outros</h3>

<h4>Prática da Respiração Compassiva</h4>
<p>Para desenvolver compaixão pelos outros:</p>
<ol>
<li>Pense em alguém que está sofrendo</li>
<li>Ao inspirar, imagine recebendo sua dor</li>
<li>Ao expirar, envie alívio e paz</li>
<li>Continue por alguns minutos</li>
</ol>

<h4>Meditação do Perdão</h4>
<p>Para relacionamentos difíceis:</p>
<ol>
<li>Comece perdoando pequenas irritações</li>
<li>Lembre-se: perdoar não é aprovar</li>
<li>Reconheça que todos cometem erros</li>
<li>Envie desejos de bem-estar</li>
<li>Seja paciente com o processo</li>
</ol>

<h3>Superando Obstáculos à Compaixão</h3>

<h4>Medo de se Tornar Complacente</h4>
<p>Muitas pessoas temem que a autocompaixão as torne preguiçosas. Na verdade, pesquisas mostram o oposto - pessoas autocompassivas são mais motivadas e resilientes.</p>

<h4>Sentir-se Indigno</h4>
<p>Se você sente que não merece compaixão:</p>
<ul>
<li>Lembre-se: todos os seres merecem bondade</li>
<li>Comece com pequenos atos de autocuidado</li>
<li>Pratique com um animal de estimação ou criança</li>
<li>Busque ajuda profissional se necessário</li>
</ul>

<h3>Compaixão em Ação</h3>

<h4>Atos de Bondade</h4>
<p>Pratique compaixão através de ações:</p>
<ul>
<li>Voluntariado em causas que importam para você</li>
<li>Pequenos atos de gentileza diários</li>
<li>Escuta ativa para amigos em dificuldades</li>
<li>Cuidado com animais ou plantas</li>
</ul>

<h4>Autocuidado Compassivo</h4>
<ul>
<li>Descanse quando estiver cansado</li>
<li>Alimente-se de forma nutritiva</li>
<li>Estabeleça limites saudáveis</li>
<li>Busque atividades que tragam alegria</li>
<li>Perdoe-se pelos erros</li>
</ul>

<h3>Integrando Compaixão no Dia a Dia</h3>

<p>Maneiras simples de praticar compaixão diariamente:</p>
<ul>
<li>Comece o dia com uma intenção compassiva</li>
<li>Use lembretes para verificar seu tom interno</li>
<li>Pratique gratidão por seu corpo e mente</li>
<li>Termine o dia refletindo sobre momentos de bondade</li>
<li>Celebre pequenos progressos</li>
</ul>

<p>Lembre-se: a compaixão é uma prática, não uma perfeição. Cada momento de bondade - para si mesmo ou outros - é uma semente de transformação plantada no mundo.</p>'
WHERE chapter = 7;

-- Atualizar capítulo 8
UPDATE book_chapters SET 
title = 'Sono Reparador e Relaxamento Noturno',
content = '<h2>A Arte do Descanso Profundo</h2>

<p>O sono é um dos pilares fundamentais da saúde mental e física. Durante o sono, nosso corpo se repara, nossa mente processa as experiências do dia, e nosso sistema nervoso se reequilibra. No entanto, em nossa sociedade acelerada, muitos de nós lutamos para obter o descanso de qualidade que precisamos.</p>

<h3>A Importância do Sono</h3>

<p>Um sono de qualidade é essencial para:</p>
<ul>
<li>Consolidação da memória</li>
<li>Regulação emocional</li>
<li>Fortalecimento do sistema imunológico</li>
<li>Reparação celular</li>
<li>Equilíbrio hormonal</li>
<li>Clareza mental e foco</li>
<li>Regulação do humor</li>
</ul>

<h3>Compreendendo os Ciclos do Sono</h3>

<p>O sono ocorre em ciclos de aproximadamente 90 minutos, cada um contendo:</p>
<ol>
<li><strong>Sono leve (N1):</strong> Transição entre vigília e sono</li>
<li><strong>Sono moderado (N2):</strong> Diminuição da atividade cerebral</li>
<li><strong>Sono profundo (N3):</strong> Reparação física e consolidação de memória</li>
<li><strong>REM:</strong> Sonhos e processamento emocional</li>
</ol>

<h3>Higiene do Sono</h3>

<h4>Ambiente Ideal</h4>
<ul>
<li><strong>Temperatura:</strong> Entre 18-21°C</li>
<li><strong>Escuridão:</strong> Use cortinas blackout ou máscara</li>
<li><strong>Silêncio:</strong> Tampões de ouvido ou ruído branco</li>
<li><strong>Conforto:</strong> Colchão e travesseiros adequados</li>
<li><strong>Limpeza:</strong> Ambiente organizado e arejado</li>
</ul>

<h4>Rotina Pré-Sono</h4>
<p>Crie um ritual de 30-60 minutos antes de dormir:</p>
<ol>
<li><strong>Desligue telas:</strong> Pelo menos 1 hora antes</li>
<li><strong>Banho morno:</strong> Relaxa músculos e baixa temperatura corporal</li>
<li><strong>Leitura leve:</strong> Evite conteúdo estimulante</li>
<li><strong>Música suave:</strong> Sons relaxantes ou silêncio</li>
<li><strong>Aromaterapia:</strong> Lavanda ou camomila</li>
</ol>

<h3>Técnicas de Relaxamento para o Sono</h3>

<h4>Respiração 4-7-8 para Dormir</h4>
<p>Especialmente eficaz para induzir o sono:</p>
<ol>
<li>Expire completamente</li>
<li>Inspire pelo nariz por 4 tempos</li>
<li>Segure por 7 tempos</li>
<li>Expire pela boca por 8 tempos</li>
<li>Repita 4-8 ciclos</li>
</ol>

<h4>Body Scan Noturno</h4>
<p>Relaxamento progressivo na cama:</p>
<ol>
<li>Deite-se confortavelmente</li>
<li>Comece pelos dedos dos pés</li>
<li>Conscientemente relaxe cada parte do corpo</li>
<li>Mova-se lentamente até o topo da cabeça</li>
<li>Permita que todo o corpo "afunde" no colchão</li>
</ol>

<h4>Visualização para o Sono</h4>
<p>Crie cenários mentais relaxantes:</p>
<ul>
<li><strong>Praia tranquila:</strong> Ondas suaves, brisa morna</li>
<li><strong>Floresta serena:</strong> Sons da natureza, ar puro</li>
<li><strong>Jardim secreto:</strong> Flores perfumadas, paz absoluta</li>
<li><strong>Nuvem flutuante:</strong> Leveza e serenidade</li>
</ul>

<h3>Lidando com Insônia e Dificuldades</h3>

<h4>Mente Acelerada</h4>
<p>Quando os pensamentos não param:</p>
<ul>
<li><strong>Técnica do "Dump Cerebral":</strong> Escreva preocupações em papel</li>
<li><strong>Lista de gratidão:</strong> Foque em aspectos positivos do dia</li>
<li><strong>Contagem regressiva:</strong> De 100 para 1, visualizando números</li>
<li><strong>Mantra repetitivo:</strong> "Relaxar... soltar... dormir..."</li>
</ul>

<h4>Ansiedade Noturna</h4>
<p>Para acalmar a ansiedade antes de dormir:</p>
<ol>
<li><strong>Reconheça:</strong> "Estou ansioso, é normal"</li>
<li><strong>Respire:</strong> Use técnicas de respiração</li>
<li><strong>Relaxe o corpo:</strong> Solte tensões físicas</li>
<li><strong>Reframe:</strong> "Posso lidar com isso amanhã"</li>
</ol>

<h4>Regra dos 20 Minutos</h4>
<p>Se não conseguir dormir em 20 minutos:</p>
<ol>
<li>Levante-se da cama</li>
<li>Vá para outro ambiente</li>
<li>Faça atividade calma (leitura, meditação)</li>
<li>Retorne à cama quando sentir sono</li>
<li>Repita se necessário</li>
</ol>

<h3>Meditações Específicas para o Sono</h3>

<h4>Meditação do Sono Profundo</h4>
<p>Guie-se através desta sequência:</p>
<ol>
<li><strong>Preparação:</strong> Posição confortável, olhos fechados</li>
<li><strong>Respiração:</strong> 10 respirações profundas</li>
<li><strong>Relaxamento:</strong> Solte cada músculo conscientemente</li>
<li><strong>Visualização:</strong> Imagine-se descendo escadas para o sono</li>
<li><strong>Entrega:</strong> Permita-se adormecer naturalmente</li>
</ol>

<h4>Yoga Nidra (Sono Yóguico)</h4>
<p>Prática de relaxamento profundo:</p>
<ul>
<li>Estado entre vigília e sono</li>
<li>Consciência sem esforço</li>
<li>Rotação da consciência pelo corpo</li>
<li>Visualizações simbólicas</li>
<li>Profundo descanso mental</li>
</ul>

<h3>Hábitos Diurnos para Melhor Sono</h3>

<h4>Exposição à Luz</h4>
<ul>
<li><strong>Manhã:</strong> Luz solar nos primeiros 30 minutos</li>
<li><strong>Dia:</strong> Máxima exposição à luz natural</li>
<li><strong>Tarde:</strong> Diminua gradualmente a intensidade</li>
<li><strong>Noite:</strong> Luz mínima e amarelada</li>
</ul>

<h4>Exercício e Sono</h4>
<ul>
<li>Exercite-se regularmente, mas não perto da hora de dormir</li>
<li>Atividades aeróbicas melhoram a qualidade do sono</li>
<li>Yoga e alongamento são ideais à noite</li>
<li>Evite exercícios intensos 3 horas antes de dormir</li>
</ul>

<h4>Alimentação e Sono</h4>
<ul>
<li><strong>Evite:</strong> Cafeína após 14h, álcool, refeições pesadas</li>
<li><strong>Inclua:</strong> Chás relaxantes, alimentos com triptofano</li>
<li><strong>Timing:</strong> Última refeição 3 horas antes de dormir</li>
<li><strong>Hidratação:</strong> Adequada durante o dia, reduzida à noite</li>
</ul>

<h3>Criando Seu Ritual Personalizado</h3>

<p>Desenvolva uma rotina que funcione para você:</p>
<ol>
<li><strong>Identifique:</strong> Que atividades mais o relaxam?</li>
<li><strong>Experimente:</strong> Teste diferentes técnicas</li>
<li><strong>Consistência:</strong> Mantenha horários regulares</li>
<li><strong>Ajuste:</strong> Modifique conforme necessário</li>
<li><strong>Paciência:</strong> Mudanças levam tempo para se estabelecer</li>
</ol>

<p>Lembre-se: o sono de qualidade é um investimento em sua saúde e bem-estar. Cada noite de descanso reparador é um presente que você dá a si mesmo para enfrentar o dia seguinte com energia e clareza.</p>'
WHERE chapter = 8;

-- Atualizar capítulo 9
UPDATE book_chapters SET 
title = 'Mantendo a Prática e Crescimento Contínuo',
content = '<h2>Sustentando Sua Jornada de Bem-Estar</h2>

<p>Estabelecer uma prática de mindfulness e bem-estar é apenas o começo. O verdadeiro desafio - e a verdadeira transformação - acontece quando conseguimos manter essa prática ao longo do tempo, integrando-a profundamente em nossas vidas e permitindo que ela evolua conosco.</p>

<h3>A Natureza da Prática Sustentável</h3>

<p>Uma prática sustentável não é sobre perfeição ou rigidez. É sobre:</p>
<ul>
<li><strong>Flexibilidade:</strong> Adaptar-se às mudanças da vida</li>
<li><strong>Compaixão:</strong> Ser gentil consigo mesmo nos altos e baixos</li>
<li><strong>Curiosidade:</strong> Manter interesse e abertura para aprender</li>
<li><strong>Paciência:</strong> Entender que crescimento leva tempo</li>
<li><strong>Consistência:</strong> Pequenas ações regulares superam grandes esforços esporádicos</li>
</ul>

<h3>Superando Obstáculos Comuns</h3>

<h4>Falta de Tempo</h4>
<p>Estratégias para integrar prática em agendas ocupadas:</p>
<ul>
<li><strong>Micro-práticas:</strong> 2-3 minutos várias vezes ao dia</li>
<li><strong>Multitasking mindful:</strong> Atenção plena durante atividades rotineiras</li>
<li><strong>Priorização:</strong> Trate bem-estar como compromisso não-negociável</li>
<li><strong>Eficiência:</strong> Combine práticas (respiração + caminhada)</li>
</ul>

<h4>Perda de Motivação</h4>
<p>Quando o entusiasmo inicial diminui:</p>
<ul>
<li><strong>Lembre-se do "porquê":</strong> Reconecte-se com suas motivações originais</li>
<li><strong>Celebre pequenas vitórias:</strong> Reconheça progressos sutis</li>
<li><strong>Varie as práticas:</strong> Experimente novas técnicas</li>
<li><strong>Busque comunidade:</strong> Pratique com outros</li>
<li><strong>Seja realista:</strong> Ajuste expectativas conforme necessário</li>
</ul>

<h4>Autocrítica e Perfeccionismo</h4>
<p>Transformando a relação com "falhas":</p>
<ul>
<li><strong>Redefina sucesso:</strong> Consistência > perfeição</li>
<li><strong>Pratique autocompaixão:</strong> Trate-se como trataria um bom amigo</li>
<li><strong>Veja interrupções como oportunidades:</strong> Cada retorno é uma vitória</li>
<li><strong>Foque no processo:</strong> Não apenas nos resultados</li>
</ul>

<h3>Criando Estruturas de Apoio</h3>

<h4>Ambiente Físico</h4>
<p>Crie espaços que apoiem sua prática:</p>
<ul>
<li><strong>Canto de meditação:</strong> Espaço dedicado, mesmo que pequeno</li>
<li><strong>Lembretes visuais:</strong> Objetos que inspirem prática</li>
<li><strong>Organização:</strong> Ambiente limpo e tranquilo</li>
<li><strong>Acessibilidade:</strong> Materiais de prática facilmente disponíveis</li>
</ul>

<h4>Rotinas e Rituais</h4>
<p>Estabeleça estruturas que facilitem a prática:</p>
<ul>
<li><strong>Horários fixos:</strong> Mesmo que flexíveis</li>
<li><strong>Gatilhos de hábito:</strong> Conecte prática a atividades existentes</li>
<li><strong>Rituais de transição:</strong> Sinalize início e fim das práticas</li>
<li><strong>Planejamento semanal:</strong> Antecipe desafios e soluções</li>
</ul>

<h4>Comunidade e Apoio Social</h4>
<p>Cultive conexões que nutram sua jornada:</p>
<ul>
<li><strong>Grupos de prática:</strong> Online ou presenciais</li>
<li><strong>Parceiro de accountability:</strong> Alguém para compartilhar a jornada</li>
<li><strong>Mentores ou professores:</strong> Orientação experiente</li>
<li><strong>Família e amigos:</strong> Eduque sobre sua prática</li>
</ul>

<h3>Evoluindo Sua Prática</h3>

<h4>Aprofundamento Gradual</h4>
<p>Como desenvolver sua prática ao longo do tempo:</p>
<ol>
<li><strong>Meses 1-3:</strong> Estabeleça consistência básica</li>
<li><strong>Meses 4-6:</strong> Explore diferentes técnicas</li>
<li><strong>Meses 7-12:</strong> Aprofunde práticas favoritas</li>
<li><strong>Ano 2+:</strong> Integre em todos os aspectos da vida</li>
</ol>

<h4>Sinais de Progresso</h4>
<p>Reconheça crescimento sutil mas significativo:</p>
<ul>
<li>Maior consciência de padrões mentais</li>
<li>Recuperação mais rápida de estresse</li>
<li>Relacionamentos mais harmoniosos</li>
<li>Maior aceitação de imperfeições</li>
<li>Presença mais natural no dia a dia</li>
<li>Menos reatividade emocional</li>
</ul>

<h3>Lidando com Períodos Difíceis</h3>

<h4>Crises e Desafios</h4>
<p>Como manter prática durante dificuldades:</p>
<ul>
<li><strong>Simplifique:</strong> Reduza para o essencial</li>
<li><strong>Adapte:</strong> Modifique práticas conforme necessário</li>
<li><strong>Use ferramentas de emergência:</strong> Técnicas rápidas para momentos agudos</li>
<li><strong>Busque apoio:</strong> Não hesite em pedir ajuda</li>
<li><strong>Seja extra gentil:</strong> Autocompaixão é crucial</li>
</ul>

<h4>Plateaus e Estagnação</h4>
<p>Quando sente que não está progredindo:</p>
<ul>
<li><strong>Reavalie objetivos:</strong> Talvez você já tenha chegado onde queria</li>
<li><strong>Experimente novidades:</strong> Novas técnicas ou abordagens</li>
<li><strong>Aprofunde o básico:</strong> Às vezes, voltar ao fundamental é o caminho</li>
<li><strong>Busque orientação:</strong> Perspectiva externa pode ajudar</li>
<li><strong>Confie no processo:</strong> Crescimento nem sempre é linear</li>
</ul>

<h3>Integrando Sabedoria na Vida</h3>

<h4>Além da Almofada</h4>
<p>Levando mindfulness para todas as áreas:</p>
<ul>
<li><strong>Trabalho:</strong> Presença em reuniões, pausas conscientes</li>
<li><strong>Relacionamentos:</strong> Escuta ativa, comunicação compassiva</li>
<li><strong>Parentalidade:</strong> Paciência, presença com filhos</li>
<li><strong>Decisões:</strong> Clareza mental, valores alinhados</li>
<li><strong>Desafios:</strong> Resiliência, perspectiva equilibrada</li>
</ul>

<h4>Servindo aos Outros</h4>
<p>Compartilhando os benefícios de sua prática:</p>
<ul>
<li><strong>Exemplo silencioso:</strong> Sua presença inspira outros</li>
<li><strong>Compartilhamento gentil:</strong> Ofereça sem impor</li>
<li><strong>Ensino informal:</strong> Técnicas simples para familiares</li>
<li><strong>Voluntariado:</strong> Use habilidades para ajudar comunidade</li>
<li><strong>Compaixão ativa:</strong> Ações baseadas em sabedoria cultivada</li>
</ul>

<h3>Recursos para Crescimento Contínuo</h3>

<h4>Educação Continuada</h4>
<ul>
<li><strong>Livros:</strong> Aprofunde conhecimento teórico e prático</li>
<li><strong>Cursos online:</strong> Programas estruturados de desenvolvimento</li>
<li><strong>Workshops:</strong> Experiências intensivas de aprendizado</li>
<li><strong>Retiros:</strong> Períodos dedicados de prática profunda</li>
<li><strong>Apps e tecnologia:</strong> Ferramentas de apoio modernas</li>
</ul>

<h4>Autoavaliação Regular</h4>
<p>Perguntas para reflexão mensal:</p>
<ul>
<li>Como minha prática evoluiu este mês?</li>
<li>Que desafios enfrentei e como os superei?</li>
<li>Onde vejo crescimento em minha vida?</li>
<li>O que gostaria de explorar no próximo mês?</li>
<li>Como posso apoiar melhor minha prática?</li>
</ul>

<h3>Visão de Longo Prazo</h3>

<p>Lembre-se de que esta jornada é para toda a vida. Não há destino final, apenas um caminho contínuo de crescimento, descoberta e despertar. Cada momento de presença, cada respiração consciente, cada ato de compaixão contribui não apenas para seu próprio bem-estar, mas para o bem-estar de todos os seres.</p>

<p>Que sua prática seja uma fonte constante de paz, sabedoria e alegria. Que você encontre força nos momentos difíceis e gratidão nos momentos de graça. E que a calma que você cultiva se irradie para o mundo, criando ondas de paz que tocam todos ao seu redor.</p>

<p><em>Que todos os seres sejam felizes. Que todos os seres estejam em paz. Que todos os seres sejam livres de sofrimento.</em></p>'
WHERE chapter = 9;