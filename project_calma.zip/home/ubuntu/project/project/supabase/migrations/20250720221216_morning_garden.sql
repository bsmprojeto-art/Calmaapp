/*
  # Create ambient sounds system

  1. New Tables
    - `ambient_sounds`
      - `id` (uuid, primary key)
      - `name` (text, sound name)
      - `description` (text, sound description)
      - `file_url` (text, URL to audio file)
      - `duration` (integer, duration in seconds)
      - `category` (text, sound category)
      - `is_active` (boolean, if sound is available)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Storage
    - Create bucket for ambient sounds
    - Set up public access policies

  3. Security
    - Enable RLS on `ambient_sounds` table
    - Add policy for public read access
*/

-- Create ambient_sounds table
CREATE TABLE IF NOT EXISTS ambient_sounds (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  file_url text NOT NULL,
  duration integer DEFAULT 0,
  category text DEFAULT 'nature',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE ambient_sounds ENABLE ROW LEVEL SECURITY;

-- Create policy for public read access
CREATE POLICY "Anyone can read ambient sounds"
  ON ambient_sounds
  FOR SELECT
  TO public
  USING (is_active = true);

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'update_ambient_sounds_updated_at'
  ) THEN
    CREATE TRIGGER update_ambient_sounds_updated_at
      BEFORE UPDATE ON ambient_sounds
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;
END $$;

-- Insert default ambient sounds (using web-based audio sources)
INSERT INTO ambient_sounds (name, description, file_url, duration, category) VALUES
  ('Chuva Suave', 'Som relaxante de chuva leve', 'https://www.soundjay.com/misc/sounds/rain-01.wav', 300, 'nature'),
  ('Ondas do Mar', 'Ondas suaves batendo na praia', 'https://www.soundjay.com/misc/sounds/ocean-wave-1.wav', 240, 'nature'),
  ('Floresta Tranquila', 'Sons da natureza em uma floresta', 'https://www.soundjay.com/misc/sounds/forest-1.wav', 360, 'nature'),
  ('Vento Suave', 'Brisa leve através das árvores', 'https://www.soundjay.com/misc/sounds/wind-1.wav', 180, 'nature'),
  ('Pássaros Cantando', 'Melodia relaxante de pássaros', 'https://www.soundjay.com/misc/sounds/birds-1.wav', 200, 'nature')
ON CONFLICT DO NOTHING;