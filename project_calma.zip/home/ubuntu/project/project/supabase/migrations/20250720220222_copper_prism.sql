/*
  # Criar estrutura para conteúdo do livro

  1. Nova Tabela
    - `book_chapters`
      - `id` (integer, primary key)
      - `chapter` (integer, número do capítulo)
      - `title` (text, título do capítulo)
      - `content` (text, conteúdo HTML do capítulo)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Segurança
    - Enable RLS na tabela `book_chapters`
    - Adicionar política para leitura pública (conteúdo é público)

  3. Dados
    - Inserir todos os capítulos do livro
*/

-- Criar tabela para capítulos do livro
CREATE TABLE IF NOT EXISTS book_chapters (
  id SERIAL PRIMARY KEY,
  chapter INTEGER NOT NULL UNIQUE,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE book_chapters ENABLE ROW LEVEL SECURITY;

-- Política para leitura pública (livro é conteúdo público)
CREATE POLICY "Anyone can read book chapters"
  ON book_chapters
  FOR SELECT
  TO public
  USING (true);

-- Inserir conteúdo dos capítulos
INSERT INTO book_chapters (chapter, title, content) VALUES
(1, 'Introdução à Calma', '
<h2>Capítulo 1: Introdução à Calma</h2>

<p>Bem-vindo à sua jornada rumo à paz interior. Em um mundo cada vez mais acelerado e cheio de distrações, encontrar momentos de calma tornou-se não apenas desejável, mas essencial para nosso bem-estar mental e físico.</p>

<p>A calma não é simplesmente a ausência de ruído ou movimento. É um estado de ser que podemos cultivar através de práticas intencionais e mindfulness. Quando estamos verdadeiramente calmos, nossa mente se torna clara, nosso corpo relaxa e nossa capacidade de responder (ao invés de reagir) às situações da vida se expande.</p>

<h3>O que você aprenderá neste livro:</h3>
<ul>
  <li>Técnicas fundamentais de respiração para acalmar o sistema nervoso</li>
  <li>Práticas de meditação adaptadas para iniciantes e praticantes avançados</li>
  <li>Métodos de relaxamento muscular progressivo</li>
  <li>Estratégias para lidar com ansiedade e estresse do dia a dia</li>
  <li>Como criar um ambiente propício à calma em sua vida</li>
</ul>

<p>Lembre-se: a jornada para a calma é pessoal e única. Seja paciente consigo mesmo e permita que cada prática se desenvolva naturalmente.</p>
'),

(2, 'A Ciência da Respiração', '
<h2>Capítulo 2: A Ciência da Respiração</h2>

<p>A respiração é nossa ferramenta mais poderosa e acessível para influenciar nosso estado mental e emocional. Diferentemente de outros processos corporais, a respiração pode ser tanto automática quanto consciente, oferecendo-nos uma ponte única entre o sistema nervoso voluntário e involuntário.</p>

<h3>Como a respiração afeta nosso corpo:</h3>

<p><strong>Sistema Nervoso Parassimpático:</strong> Quando respiramos de forma lenta e profunda, ativamos o sistema nervoso parassimpático, responsável pelo estado de "descanso e digestão". Isso reduz a produção de cortisol (hormônio do estresse) e promove a liberação de endorfinas.</p>

<p><strong>Oxigenação Cerebral:</strong> Uma respiração adequada garante que nosso cérebro receba oxigênio suficiente, melhorando a clareza mental e a capacidade de concentração.</p>

<h3>Técnicas Fundamentais:</h3>

<h4>1. Respiração Diafragmática</h4>
<p>Coloque uma mão no peito e outra no abdômen. Respire de forma que apenas a mão do abdômen se mova. Isso garante que você está usando o diafragma corretamente.</p>

<h4>2. Respiração 4-7-8</h4>
<p>Inspire por 4 tempos, segure por 7, expire por 8. Esta técnica é especialmente eficaz para reduzir ansiedade e promover o sono.</p>

<h4>3. Respiração Box (Quadrada)</h4>
<p>Inspire por 4, segure por 4, expire por 4, segure por 4. Excelente para melhorar o foco e a concentração.</p>

<p>Pratique essas técnicas diariamente, começando com apenas 5 minutos por dia.</p>
'),

(3, 'Meditação para Iniciantes', '
<h2>Capítulo 3: Meditação para Iniciantes</h2>

<p>A meditação é uma prática milenar que treina nossa mente para focar no momento presente. Contrariamente ao que muitos pensam, meditar não significa "esvaziar a mente", mas sim observar nossos pensamentos sem julgamento.</p>

<h3>Preparando-se para meditar:</h3>

<h4>Ambiente</h4>
<ul>
  <li>Escolha um local silencioso e confortável</li>
  <li>Use roupas soltas e confortáveis</li>
  <li>Mantenha a temperatura agradável</li>
  <li>Desligue dispositivos eletrônicos</li>
</ul>

<h4>Postura</h4>
<ul>
  <li>Sente-se com a coluna ereta, mas não rígida</li>
  <li>Relaxe os ombros</li>
  <li>Apoie as mãos confortavelmente</li>
  <li>Feche os olhos suavemente</li>
</ul>

<h3>Meditação Básica - Foco na Respiração:</h3>

<ol>
  <li><strong>Estabeleça sua intenção:</strong> Dedique alguns momentos para definir por que está meditando.</li>
  <li><strong>Observe sua respiração natural:</strong> Não tente controlá-la, apenas observe.</li>
  <li><strong>Quando a mente divagar:</strong> Isso é normal! Gentilmente retorne o foco à respiração.</li>
  <li><strong>Use uma âncora:</strong> Conte as respirações de 1 a 10, depois recomece.</li>
  <li><strong>Termine gradualmente:</strong> Mova dedos e pés antes de abrir os olhos.</li>
</ol>

<h3>Dicas para iniciantes:</h3>
<ul>
  <li>Comece com apenas 5-10 minutos por dia</li>
  <li>Seja consistente - é melhor meditar 5 minutos todos os dias do que 30 minutos uma vez por semana</li>
  <li>Não se julgue - cada sessão é diferente</li>
  <li>Use aplicativos ou meditações guiadas se necessário</li>
</ul>
'),

(4, 'Relaxamento Muscular Progressivo', '
<h2>Capítulo 4: Relaxamento Muscular Progressivo</h2>

<p>O Relaxamento Muscular Progressivo (RMP) é uma técnica desenvolvida pelo médico Edmund Jacobson na década de 1920. Esta prática envolve tensionar e relaxar sistematicamente diferentes grupos musculares, ajudando-nos a reconhecer a diferença entre tensão e relaxamento.</p>

<h3>Benefícios do RMP:</h3>
<ul>
  <li>Redução significativa da tensão muscular</li>
  <li>Diminuição da ansiedade e estresse</li>
  <li>Melhoria na qualidade do sono</li>
  <li>Maior consciência corporal</li>
  <li>Alívio de dores de cabeça tensionais</li>
</ul>

<h3>Como praticar o RMP:</h3>

<h4>Preparação:</h4>
<ul>
  <li>Deite-se confortavelmente em um local silencioso</li>
  <li>Use roupas soltas</li>
  <li>Remova sapatos e acessórios</li>
  <li>Feche os olhos</li>
</ul>

<h4>Sequência (15-20 minutos):</h4>

<p><strong>1. Pés e panturrilhas (2 minutos):</strong></p>
<ul>
  <li>Contraia os músculos dos pés e panturrilhas por 5 segundos</li>
  <li>Relaxe completamente por 10-15 segundos</li>
  <li>Observe a sensação de relaxamento</li>
</ul>

<p><strong>2. Coxas e glúteos (2 minutos):</strong></p>
<ul>
  <li>Tensione os músculos das coxas e glúteos</li>
  <li>Mantenha por 5 segundos</li>
  <li>Relaxe e observe a diferença</li>
</ul>

<p><strong>3. Abdômen (2 minutos):</strong></p>
<ul>
  <li>Contraia os músculos abdominais</li>
  <li>Segure por 5 segundos</li>
  <li>Relaxe profundamente</li>
</ul>

<p><strong>4. Mãos e braços (3 minutos):</strong></p>
<ul>
  <li>Feche os punhos e tensione braços e antebraços</li>
  <li>Mantenha a tensão por 5 segundos</li>
  <li>Relaxe completamente, deixando os braços caírem naturalmente</li>
</ul>

<p><strong>5. Ombros e pescoço (3 minutos):</strong></p>
<ul>
  <li>Levante os ombros em direção às orelhas</li>
  <li>Tensione o pescoço</li>
  <li>Segure por 5 segundos e relaxe</li>
</ul>

<p><strong>6. Rosto (3 minutos):</strong></p>
<ul>
  <li>Franza a testa, feche os olhos firmemente</li>
  <li>Aperte os lábios</li>
  <li>Mantenha por 5 segundos</li>
  <li>Relaxe completamente, deixando o rosto suave</li>
</ul>

<p><strong>Finalização:</strong> Permaneça relaxado por alguns minutos, observando a sensação de calma em todo o corpo.</p>
'),

(5, 'Mindfulness no Dia a Dia', '
<h2>Capítulo 5: Mindfulness no Dia a Dia</h2>

<p>Mindfulness, ou atenção plena, é a prática de estar completamente presente no momento atual, observando nossos pensamentos, sentimentos e sensações sem julgamento. Não é necessário reservar horas do dia para praticar - podemos integrar mindfulness em nossas atividades cotidianas.</p>

<h3>Princípios fundamentais do Mindfulness:</h3>

<h4>1. Atenção ao presente</h4>
<p>Foque no que está acontecendo agora, não no passado ou futuro.</p>

<h4>2. Observação sem julgamento</h4>
<p>Note seus pensamentos e sentimentos sem rotulá-los como "bons" ou "ruins".</p>

<h4>3. Aceitação</h4>
<p>Aceite o momento presente como ele é, sem tentar mudá-lo.</p>

<h4>4. Curiosidade gentil</h4>
<p>Aproxime-se de suas experiências com interesse e compaixão.</p>

<h3>Práticas de Mindfulness para o cotidiano:</h3>

<h4>Mindfulness ao comer:</h4>
<ul>
  <li>Coma devagar, saboreando cada mordida</li>
  <li>Observe cores, texturas e sabores</li>
  <li>Note as sensações de fome e saciedade</li>
  <li>Evite distrações como TV ou celular</li>
</ul>

<h4>Mindfulness ao caminhar:</h4>
<ul>
  <li>Sinta seus pés tocando o chão</li>
  <li>Observe o movimento das pernas</li>
  <li>Note os sons ao seu redor</li>
  <li>Respire conscientemente enquanto caminha</li>
</ul>

<h4>Mindfulness nas tarefas domésticas:</h4>
<ul>
  <li>Lave louça focando na temperatura da água</li>
  <li>Ao limpar, observe os movimentos repetitivos</li>
  <li>Transforme tarefas rotineiras em momentos de presença</li>
</ul>

<h4>Técnica dos 5 sentidos (para momentos de ansiedade):</h4>
<ul>
  <li>5 coisas que você pode VER</li>
  <li>4 coisas que você pode TOCAR</li>
  <li>3 coisas que você pode OUVIR</li>
  <li>2 coisas que você pode CHEIRAR</li>
  <li>1 coisa que você pode SABOREAR</li>
</ul>

<h3>Criando lembretes de mindfulness:</h3>
<ul>
  <li>Configure alarmes suaves no celular</li>
  <li>Use objetos como âncoras (uma pedra no bolso)</li>
  <li>Pratique mindfulness em transições (antes de entrar em casa)</li>
  <li>Use a respiração como ponto de retorno ao presente</li>
</ul>
'),

(6, 'Lidando com Ansiedade e Estresse', '
<h2>Capítulo 6: Lidando com Ansiedade e Estresse</h2>

<p>A ansiedade e o estresse são respostas naturais do nosso corpo a situações desafiadoras. No entanto, quando se tornam crônicos, podem impactar significativamente nossa qualidade de vida. Felizmente, existem técnicas eficazes para gerenciar esses estados.</p>

<h3>Entendendo a ansiedade:</h3>

<p>A ansiedade é uma resposta do sistema nervoso simpático que prepara nosso corpo para "lutar ou fugir". Sintomas comuns incluem:</p>
<ul>
  <li>Batimentos cardíacos acelerados</li>
  <li>Respiração superficial</li>
  <li>Tensão muscular</li>
  <li>Pensamentos acelerados</li>
  <li>Sensação de inquietação</li>
</ul>

<h3>Técnicas imediatas para ansiedade:</h3>

<h4>1. Respiração 4-7-8 (técnica de emergência):</h4>
<ul>
  <li>Inspire pelo nariz por 4 segundos</li>
  <li>Segure a respiração por 7 segundos</li>
  <li>Expire pela boca por 8 segundos</li>
  <li>Repita 4 vezes</li>
</ul>

<h4>2. Técnica de grounding 5-4-3-2-1:</h4>
<p>Esta técnica ajuda a trazer você de volta ao momento presente quando a ansiedade está alta.</p>

<h4>3. Relaxamento muscular rápido:</h4>
<ul>
  <li>Tensione todos os músculos do corpo por 5 segundos</li>
  <li>Relaxe completamente</li>
  <li>Respire profundamente</li>
  <li>Repita 3 vezes</li>
</ul>

<h3>Estratégias de longo prazo:</h3>

<h4>Reestruturação cognitiva:</h4>
<p>Questione pensamentos ansiosos:</p>
<ul>
  <li>"Este pensamento é realista?"</li>
  <li>"Qual é a evidência para e contra?"</li>
  <li>"Qual seria o pior cenário realista?"</li>
  <li>"Como eu lidaria se isso acontecesse?"</li>
</ul>

<h4>Criando um kit de ferramentas para ansiedade:</h4>
<ul>
  <li>Lista de técnicas de respiração</li>
  <li>Músicas relaxantes</li>
  <li>Frases de autocompaixão</li>
  <li>Contatos de apoio</li>
  <li>Atividades que trazem calma</li>
</ul>

<h3>Prevenção do estresse:</h3>

<h4>Higiene do sono:</h4>
<ul>
  <li>Durma 7-9 horas por noite</li>
  <li>Mantenha horários regulares</li>
  <li>Evite telas 1 hora antes de dormir</li>
  <li>Crie um ritual relaxante para a noite</li>
</ul>

<h4>Exercício regular:</h4>
<ul>
  <li>30 minutos de atividade física moderada</li>
  <li>Caminhadas na natureza</li>
  <li>Yoga ou tai chi</li>
  <li>Qualquer movimento que você goste</li>
</ul>

<h4>Nutrição para o bem-estar mental:</h4>
<ul>
  <li>Reduza cafeína e açúcar</li>
  <li>Mantenha-se hidratado</li>
  <li>Coma alimentos ricos em ômega-3</li>
  <li>Evite álcool em excesso</li>
</ul>

<p><strong>Lembre-se:</strong> Se a ansiedade ou estresse estão interferindo significativamente em sua vida, considere buscar ajuda profissional. Não há vergonha em pedir apoio.</p>
'),

(7, 'Cultivando Autocompaixão', '
<h2>Capítulo 7: Cultivando Autocompaixão</h2>

<p>A autocompaixão é talvez uma das habilidades mais importantes que podemos desenvolver em nossa jornada de bem-estar mental. Ela envolve tratar a nós mesmos com a mesma gentileza que oferecemos a um bom amigo em momentos difíceis.</p>

<h3>Os três pilares da autocompaixão:</h3>

<h4>1. Bondade consigo mesmo</h4>
<p>Em vez de autocrítica severa, pratique falar consigo mesmo com gentileza e compreensão. Quando cometer um erro, pergunte-se: "O que eu diria a um amigo querido nesta situação?"</p>

<h4>2. Humanidade comum</h4>
<p>Reconheça que o sofrimento e os erros fazem parte da experiência humana. Você não está sozinho em suas lutas - todos passamos por dificuldades.</p>

<h4>3. Mindfulness</h4>
<p>Observe seus sentimentos difíceis sem se identificar completamente com eles ou suprimi-los. Permita que existam sem julgamento.</p>

<h3>Práticas de autocompaixão:</h3>

<h4>Meditação da autocompaixão:</h4>
<ol>
  <li>Sente-se confortavelmente e feche os olhos</li>
  <li>Coloque as mãos sobre o coração</li>
  <li>Respire profundamente algumas vezes</li>
  <li>Repita silenciosamente: "Que eu seja feliz. Que eu seja saudável. Que eu viva com facilidade."</li>
  <li>Sinta o calor e a bondade dessas palavras</li>
</ol>

<h4>Carta de autocompaixão:</h4>
<p>Escreva uma carta para si mesmo sobre uma situação difícil, usando a perspectiva de um amigo amoroso e compreensivo.</p>

<h4>Pausa da autocompaixão:</h4>
<p>Quando enfrentar dificuldades, faça uma pausa e:</p>
<ul>
  <li>Reconheça: "Este é um momento de sofrimento"</li>
  <li>Normalize: "O sofrimento faz parte da vida"</li>
  <li>Ofereça bondade: "Que eu seja gentil comigo mesmo"</li>
</ul>

<h3>Superando a resistência à autocompaixão:</h3>

<p>Muitas pessoas resistem à autocompaixão por medo de se tornarem complacentes. Na verdade, pesquisas mostram que a autocompaixão aumenta a motivação e a resiliência.</p>

<h4>Mitos sobre autocompaixão:</h4>
<ul>
  <li><strong>Mito:</strong> Autocompaixão é autoindulgência</li>
  <li><strong>Realidade:</strong> Autocompaixão promove crescimento e responsabilidade</li>
  <li><strong>Mito:</strong> Preciso ser duro comigo mesmo para melhorar</li>
  <li><strong>Realidade:</strong> Gentileza consigo mesmo é mais motivadora que autocrítica</li>
</ul>

<p>Lembre-se: você merece a mesma compaixão que oferece aos outros. Comece hoje a cultivar uma relação mais amorosa consigo mesmo.</p>
'),

(8, 'Criando Rituais de Calma', '
<h2>Capítulo 8: Criando Rituais de Calma</h2>

<p>Os rituais são práticas intencionais que nos ajudam a criar estrutura e significado em nossas vidas. Rituais de calma são especialmente poderosos porque sinalizam ao nosso sistema nervoso que é hora de relaxar e se reconectar conosco.</p>

<h3>O poder dos rituais:</h3>

<p>Rituais funcionam porque:</p>
<ul>
  <li>Criam previsibilidade em um mundo caótico</li>
  <li>Ativam o sistema nervoso parassimpático</li>
  <li>Proporcionam momentos de pausa e reflexão</li>
  <li>Fortalecem nossa conexão com valores importantes</li>
</ul>

<h3>Rituais matinais para começar com calma:</h3>

<h4>Ritual dos 10 minutos:</h4>
<ol>
  <li>Acorde 10 minutos mais cedo</li>
  <li>Beba um copo de água mindfully</li>
  <li>Faça 3 respirações profundas</li>
  <li>Defina uma intenção para o dia</li>
  <li>Pratique gratidão por 3 coisas</li>
</ol>

<h4>Ritual do café/chá consciente:</h4>
<ul>
  <li>Prepare sua bebida com atenção total</li>
  <li>Observe o aroma, a cor, a temperatura</li>
  <li>Beba o primeiro gole em silêncio</li>
  <li>Use este momento como meditação</li>
</ul>

<h3>Rituais noturnos para encerrar com paz:</h3>

<h4>Ritual de descompressão:</h4>
<ol>
  <li>Desligue dispositivos eletrônicos 1 hora antes de dormir</li>
  <li>Tome um banho morno com óleos essenciais</li>
  <li>Pratique journaling - escreva 3 coisas boas do dia</li>
  <li>Faça uma meditação de gratidão de 5 minutos</li>
  <li>Leia algo inspirador por 10 minutos</li>
</ol>

<h3>Rituais para momentos de transição:</h3>

<h4>Entre trabalho e casa:</h4>
<ul>
  <li>Faça 5 respirações profundas no carro</li>
  <li>Ouça uma música que te acalma</li>
  <li>Defina a intenção de estar presente com a família</li>
</ul>

<h4>Antes de reuniões importantes:</h4>
<ul>
  <li>Respire fundo 3 vezes</li>
  <li>Coloque os pés no chão e sinta a conexão</li>
  <li>Defina uma intenção positiva</li>
</ul>

<h3>Criando seus próprios rituais:</h3>

<h4>Elementos essenciais:</h4>
<ul>
  <li><strong>Simplicidade:</strong> Mantenha simples para ser sustentável</li>
  <li><strong>Consistência:</strong> Pratique no mesmo horário/local</li>
  <li><strong>Significado:</strong> Escolha ações que ressoem com você</li>
  <li><strong>Flexibilidade:</strong> Adapte conforme necessário</li>
</ul>

<p>Lembre-se: o objetivo não é perfeição, mas criar momentos intencionais de calma em sua rotina diária.</p>
'),

(9, 'Técnicas de Emergência para Crises', '
<h2>Capítulo 9: Técnicas de Emergência para Crises</h2>

<div style="background: linear-gradient(135deg, #ef4444, #dc2626); color: white; padding: 20px; border-radius: 12px; margin: 20px 0; border-left: 6px solid #fbbf24;">
  <h3 style="color: white; margin-top: 0;">⚠️ IMPORTANTE - LEIA PRIMEIRO</h3>
  <p><strong>Se você está em crise suicida ou pensando em se machucar:</strong></p>
  <ul style="margin: 10px 0;">
    <li><strong>CVV (Centro de Valorização da Vida):</strong> 188 (24h, gratuito)</li>
    <li><strong>SAMU:</strong> 192</li>
    <li><strong>Bombeiros:</strong> 193</li>
    <li><strong>Polícia Militar:</strong> 190</li>
  </ul>
  <p><strong>Você não está sozinho. Sua vida tem valor. Procure ajuda profissional.</strong></p>
</div>

<p>Este capítulo contém técnicas para momentos de crise emocional intensa, ataques de pânico ou ansiedade severa. Estas são ferramentas de primeiros socorros emocionais.</p>

<h3>🚨 Técnica STOP para Ataques de Pânico:</h3>

<h4>S - PARE</h4>
<p>Pare o que está fazendo. Reconheça que está tendo um ataque de pânico.</p>

<h4>T - RESPIRE (Take a breath)</h4>
<p>Respire lenta e profundamente. Conte: inspire por 4, segure por 4, expire por 6.</p>

<h4>O - OBSERVE</h4>
<p>Observe ao seu redor. Nomeie 5 coisas que vê, 4 que ouve, 3 que pode tocar.</p>

<h4>P - PROSSIGA (Proceed)</h4>
<p>Continue com uma ação calmante: caminhar, beber água, ligar para alguém.</p>

<h3>🆘 Técnica de Emergência 5-4-3-2-1:</h3>

<p>Para ansiedade severa ou dissociação:</p>
<ul>
  <li><strong>5 coisas que você VÊ</strong> - Olhe ao redor e nomeie</li>
  <li><strong>4 coisas que você TOCA</strong> - Sinta texturas diferentes</li>
  <li><strong>3 coisas que você OUVE</strong> - Preste atenção aos sons</li>
  <li><strong>2 coisas que você CHEIRA</strong> - Identifique aromas</li>
  <li><strong>1 coisa que você SABOREIA</strong> - Note o gosto na boca</li>
</ul>

<h3>❄️ Técnica do Gelo (para autolesão):</h3>

<p>Se sentir vontade de se machucar:</p>
<ul>
  <li>Segure cubos de gelo nas mãos</li>
  <li>Coloque gelo no pulso ou pescoço</li>
  <li>Tome um banho muito frio</li>
  <li>Mastigue algo muito azedo ou picante</li>
</ul>

<h3>🌊 Respiração de Emergência:</h3>

<h4>Para hiperventilação:</h4>
<ol>
  <li>Respire em um saco de papel (ou faça concha com as mãos)</li>
  <li>Inspire por 3 segundos, expire por 6</li>
  <li>Repita até a respiração normalizar</li>
  <li>Foque em expirar mais longo que inspirar</li>
</ol>

<h3>🧠 Técnicas de Grounding Mental:</h3>

<h4>Contagem regressiva:</h4>
<ul>
  <li>Conte de 100 para 0 de 7 em 7</li>
  <li>Recite o alfabeto de trás para frente</li>
  <li>Nomeie países, cores, animais em ordem alfabética</li>
</ul>

<h4>Afirmações de emergência:</h4>
<ul>
  <li>"Isto vai passar. Eu já passei por isso antes."</li>
  <li>"Eu estou seguro agora. Isto é temporário."</li>
  <li>"Eu posso lidar com isto. Eu sou mais forte do que penso."</li>
  <li>"Este sentimento é intenso, mas não é perigoso."</li>
</ul>

<h3>📱 Kit de Emergência Digital:</h3>

<p>Tenha sempre à mão:</p>
<ul>
  <li>Números de emergência salvos</li>
  <li>Lista de pessoas de confiança para ligar</li>
  <li>Playlist de músicas calmantes</li>
  <li>Fotos que trazem paz</li>
  <li>Aplicativo de meditação</li>
  <li>Notas com afirmações positivas</li>
</ul>

<h3>🏥 Quando buscar ajuda profissional:</h3>

<ul>
  <li>Pensamentos de autolesão ou suicídio</li>
  <li>Ataques de pânico frequentes</li>
  <li>Incapacidade de funcionar no dia a dia</li>
  <li>Uso de substâncias para lidar com emoções</li>
  <li>Isolamento social extremo</li>
</ul>

<div style="background: linear-gradient(135deg, #10b981, #059669); color: white; padding: 20px; border-radius: 12px; margin: 20px 0;">
  <h3 style="color: white; margin-top: 0;">💚 Lembre-se sempre:</h3>
  <p>Pedir ajuda é um sinal de força, não de fraqueza. Você merece apoio e cuidado. Estas técnicas são temporárias - busque acompanhamento profissional para cuidado contínuo.</p>
</div>

<p><strong>Recursos adicionais:</strong></p>
<ul>
  <li>CVV: www.cvv.org.br</li>
  <li>CAPS (Centro de Atenção Psicossocial) da sua cidade</li>
  <li>UBS (Unidade Básica de Saúde) mais próxima</li>
  <li>Psicólogos online: Zenklub, Vittude, Telavita</li>
</ul>
');

-- Função para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Trigger para atualizar updated_at automaticamente
CREATE TRIGGER update_book_chapters_updated_at 
    BEFORE UPDATE ON book_chapters 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();