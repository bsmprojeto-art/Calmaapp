import { createClient, SupabaseClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

let supabase: SupabaseClient;

if (!supabaseUrl || !supabaseAnonKey) {
  console.error(
    "Erro: As variáveis de ambiente VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY não estão configuradas.\n" +
    "Por favor, crie um arquivo .env na raiz do projeto com suas credenciais do Supabase.\n" +
    "Exemplo: VITE_SUPABASE_URL=https://your-project.supabase.co\n" +
    "         VITE_SUPABASE_ANON_KEY=your-anon-key"
  );
  // Fallback para valores de exemplo para evitar crash, mas as funcionalidades do Supabase não funcionarão.
  const exampleUrl = 'https://example.supabase.co';
  const exampleAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImV4YW1wbGUiLCJyb2xlIjoiYW5vbiIsImlhdCI6MTY3ODkwNTYwMCwiZXhwIjoxOTk0MjY1NjAwfQ.example_anon_key';
  supabase = createClient(exampleUrl, exampleAnonKey);
} else {
  supabase = createClient(supabaseUrl, supabaseAnonKey);
}

export { supabase };

export const ADMIN_EMAIL = import.meta.env.VITE_ADMIN_EMAIL || 'bsmprojeto@gmail.com';

// Database types
export interface BlogPost {
  id: string;
  title: string;
  content: string;
  created_at: string;
  author_email?: string;
}

export interface UserProgress {
  id: string;
  user_id: string;
  total_sessions: number;
  total_time: number;
  current_streak: number;
  longest_streak: number;
  last_session_date: string;
  created_at: string;
  updated_at: string;
}

export interface NewsletterSubscription {
  id: string;
  email: string;
  subscribed_at: string;
  is_active: boolean;
}

// Auth helpers
export const getCurrentUser = async () => {
  const { data: { user } } = await supabase.auth.getUser();
  return user;
};

export const isAdmin = async () => {
  const user = await getCurrentUser();
  return user?.email === ADMIN_EMAIL;
};

// Progress helpers
export const getUserProgress = async (userId: string) => {
  const { data, error } = await supabase
    .from('user_progress')
    .select('*')
    .eq('user_id', userId)
    .single();
  
  if (error && error.code !== 'PGRST116') {
    console.error('Error fetching user progress:', error);
    return null;
  }
  
  return data;
};

export const updateUserProgress = async (userId: string, sessionTime: number) => {
  const existingProgress = await getUserProgress(userId);
  const today = new Date().toISOString().split('T')[0];
  
  if (existingProgress) {
    const lastSessionDate = existingProgress.last_session_date;
    const isConsecutiveDay = lastSessionDate === today || 
      (new Date(today).getTime() - new Date(lastSessionDate).getTime()) === 86400000;
    
    const newStreak = isConsecutiveDay ? existingProgress.current_streak + 1 : 1;
    
    const { error } = await supabase
      .from('user_progress')
      .update({
        total_sessions: existingProgress.total_sessions + 1,
        total_time: existingProgress.total_time + sessionTime,
        current_streak: newStreak,
        longest_streak: Math.max(existingProgress.longest_streak, newStreak),
        last_session_date: today,
        updated_at: new Date().toISOString()
      })
      .eq('user_id', userId);
    
    if (error) {
      console.error('Error updating user progress:', error);
    }
  } else {
    const { error } = await supabase
      .from('user_progress')
      .insert({
        user_id: userId,
        total_sessions: 1,
        total_time: sessionTime,
        current_streak: 1,
        longest_streak: 1,
        last_session_date: today
      });
    
    if (error) {
      console.error('Error creating user progress:', error);
    }
  }
};

// Newsletter helpers
export const subscribeToNewsletter = async (email: string) => {
  // Check if Supabase is properly configured
  if (supabaseUrl === 'https://demo.supabase.co' || supabaseAnonKey === 'demo-key') {
    // Simulate successful subscription for demo purposes
    console.log('Demo mode: Newsletter subscription for', email);
    return { success: true, data: { email, subscribed_at: new Date().toISOString() } };
  }

  const { data, error } = await supabase
    .from('newsletter_subscriptions')
    .insert({
      email,
      is_active: true
    })
    .select()
    .single();
  
  if (error) {
    console.error('Error subscribing to newsletter:', error);
    return { success: false, error: error.message };
  }
  
  return { success: true, data };
};

// Blog helpers
export const getBlogPosts = async () => {
  const { data, error } = await supabase
    .from('blog_posts')
    .select('*')
    .order('created_at', { ascending: false });
  
  if (error) {
    console.error('Error fetching blog posts:', error);
    return [];
  }
  
  return data || [];
};

export const createBlogPost = async (title: string, content: string) => {
  const user = await getCurrentUser();
  if (!user || user.email !== ADMIN_EMAIL) {
    throw new Error('Unauthorized');
  }
  
  const { data, error } = await supabase
    .from('blog_posts')
    .insert({
      title,
      content,
      author_email: user.email
    })
    .select()
    .single();
  
  if (error) {
    console.error('Error creating blog post:', error);
    throw error;
  }
  
  return data;
};

