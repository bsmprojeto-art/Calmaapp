import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Music } from 'lucide-react';
import { supabase, type AmbientSound } from '../lib/supabase';

type BreathingPhase = 'inhale' | 'hold' | 'exhale' | 'pause';

interface BreathingPattern {
  name: string;
  description: string;
  pattern: [number, number, number, number]; // [inhale, hold, exhale, pause]
  color: string;
}

const breathingPatterns: BreathingPattern[] = [
  {
    name: '4-7-8 (Relaxamento)',
    description: 'Técnica para reduzir ansiedade e promover relaxamento',
    pattern: [4, 7, 8, 0],
    color: 'from-blue-500 to-cyan-600'
  },
  {
    name: 'Box Breathing',
    description: 'Respiração quadrada para foco e concentração',
    pattern: [4, 4, 4, 4],
    color: 'from-purple-500 to-indigo-600'
  },
  {
    name: 'Respiração Simples',
    description: 'Padrão básico para iniciantes',
    pattern: [4, 2, 4, 2],
    color: 'from-green-500 to-teal-600'
  }
];

export default function BreathingExercise() {
  const [selectedPattern, setSelectedPattern] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const [currentPhase, setCurrentPhase] = useState<BreathingPhase>('inhale');
  const [timeLeft, setTimeLeft] = useState(breathingPatterns[0].pattern[0]);
  const [cycle, setCycle] = useState(0);
  const [ambientSoundEnabled, setAmbientSoundEnabled] = useState(false);
  const [availableSounds, setAvailableSounds] = useState<AmbientSound[]>([]);
  const [selectedSoundId, setSelectedSoundId] = useState<string>('');
  const ambientAudioRef = useRef<HTMLAudioElement | null>(null);

  const pattern = breathingPatterns[selectedPattern];
  const [inhale, hold, exhale, pause] = pattern.pattern;

  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (isActive) {
      interval = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            // Move to next phase
            setCurrentPhase((currentPhase) => {
              switch (currentPhase) {
                case 'inhale':
                  return hold > 0 ? 'hold' : 'exhale';
                case 'hold':
                  return 'exhale';
                case 'exhale':
                  return pause > 0 ? 'pause' : 'inhale';
                case 'pause':
                  setCycle(c => c + 1);
                  return 'inhale';
                default:
                  return 'inhale';
              }
            });
            return getPhaseTime();
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => clearInterval(interval);
  }, [isActive, currentPhase, inhale, hold, exhale, pause]);

  // Load available sounds from Supabase
  useEffect(() => {
    const loadAmbientSounds = async () => {
      try {
        const { data, error } = await supabase
          .from('ambient_sounds')
          .select('*')
          .eq('is_active', true)
          .order('name');

        if (!error && data) {
          setAvailableSounds(data);
          if (data.length > 0) {
            setSelectedSoundId(data[0].id);
          }
        }
      } catch (err) {
        console.error('Erro ao carregar sons ambiente:', err);
      }
    };

    loadAmbientSounds();
  }, []);

  // Initialize and handle ambient sound
  useEffect(() => {
    if (selectedSoundId && availableSounds.length > 0) {
      const selectedSound = availableSounds.find(s => s.id === selectedSoundId);
      if (selectedSound) {
        if (!ambientAudioRef.current) {
          ambientAudioRef.current = new Audio();
          ambientAudioRef.current.loop = true;
          ambientAudioRef.current.volume = 0.2;
        }
        ambientAudioRef.current.src = selectedSound.file_url;
      }
    }
  }, [selectedSoundId, availableSounds]);

  useEffect(() => {
    if (ambientAudioRef.current) {
      if (ambientSoundEnabled && isActive) {
        ambientAudioRef.current.play().catch(() => {
          console.log('Autoplay bloqueado pelo navegador');
        });
      } else {
        ambientAudioRef.current.pause();
      }
    }
  }, [ambientSoundEnabled, isActive]);

  const getPhaseTime = () => {
    switch (currentPhase) {
      case 'inhale': return hold > 0 ? hold : exhale;
      case 'hold': return exhale;
      case 'exhale': return pause > 0 ? pause : inhale;
      case 'pause': return inhale;
      default: return inhale;
    }
  };

  const getPhaseInstruction = () => {
    switch (currentPhase) {
      case 'inhale': return 'Inspire';
      case 'hold': return 'Segure';
      case 'exhale': return 'Expire';
      case 'pause': return 'Pausa';
    }
  };

  const getCircleScale = () => {
    const totalTime = getPhaseTime();
    const progress = (totalTime - timeLeft) / totalTime;
    
    switch (currentPhase) {
      case 'inhale': return 0.5 + (progress * 0.5);
      case 'hold': return 1;
      case 'exhale': return 1 - (progress * 0.5);
      case 'pause': return 0.5;
      default: return 0.5;
    }
  };

  const toggleExercise = () => {
    setIsActive(!isActive);
  };

  const resetExercise = () => {
    setIsActive(false);
    setCurrentPhase('inhale');
    setTimeLeft(pattern.pattern[0]);
    setCycle(0);
  };

  const selectPattern = (index: number) => {
    if (!isActive) {
      setSelectedPattern(index);
      setCurrentPhase('inhale');
      setTimeLeft(breathingPatterns[index].pattern[0]);
      setCycle(0);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white rounded-2xl shadow-xl p-8">
        <h2 className="text-3xl font-bold text-center text-gray-800 mb-8">
          Exercícios de Respiração
        </h2>

        {/* Pattern Selection */}
        <div className="mb-8">
          <label className="block text-sm font-medium text-gray-700 mb-4">
            Escolha um padrão de respiração
          </label>
          <div className="space-y-3">
            {breathingPatterns.map((patternItem, index) => (
              <button
                key={index}
                onClick={() => selectPattern(index)}
                disabled={isActive}
                className={`w-full p-4 rounded-lg text-left transition-all duration-200 ${
                  selectedPattern === index
                    ? `bg-gradient-to-r ${patternItem.color} text-white shadow-lg`
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                } ${isActive ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                <div className="font-semibold">{patternItem.name}</div>
                <div className="text-sm opacity-90">{patternItem.description}</div>
                <div className="text-xs mt-1 opacity-75">
                  Padrão: {patternItem.pattern.join('-')} segundos
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Breathing Circle */}
        <div className="relative mb-8">
          <div className="w-80 h-80 mx-auto flex items-center justify-center">
            <div
              className={`w-64 h-64 rounded-full bg-gradient-to-r ${pattern.color} flex items-center justify-center text-white transition-transform duration-1000 ease-in-out shadow-2xl`}
              style={{ transform: `scale(${getCircleScale()})` }}
            >
              <div className="text-center">
                <div className="text-2xl font-bold mb-2">
                  {getPhaseInstruction()}
                </div>
                <div className="text-4xl font-bold">
                  {timeLeft}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="text-center mb-6">
          <div className="text-lg text-gray-600">
            Ciclos completados: <span className="font-bold text-indigo-600">{cycle}</span>
          </div>
        </div>

        {/* Controls */}
        <div className="flex justify-center space-x-4 mb-6">
          <button
            onClick={toggleExercise}
            className="flex items-center justify-center w-16 h-16 bg-indigo-600 text-white rounded-full hover:bg-indigo-700 transition-colors duration-200 shadow-lg"
          >
            {isActive ? <Pause className="w-8 h-8" /> : <Play className="w-8 h-8 ml-1" />}
          </button>
          <button
            onClick={resetExercise}
            className="flex items-center justify-center w-16 h-16 bg-gray-600 text-white rounded-full hover:bg-gray-700 transition-colors duration-200 shadow-lg"
          >
            <RotateCcw className="w-8 h-8" />
          </button>
          {availableSounds.length > 0 && (
            <button
              onClick={() => setAmbientSoundEnabled(!ambientSoundEnabled)}
              className={`flex items-center justify-center w-16 h-16 text-white rounded-full transition-colors duration-200 shadow-lg ${
                ambientSoundEnabled 
                  ? 'bg-emerald-600 hover:bg-emerald-700' 
                  : 'bg-gray-400 hover:bg-gray-500'
              }`}
            >
              <Music className="w-8 h-8" />
            </button>
          )}
        </div>

        {/* Sound Selection */}
        {availableSounds.length > 0 && (
          <div className="text-center mb-6">
            <div className="flex flex-col sm:flex-row items-center justify-center gap-2 text-sm text-gray-600">
              <span>Som ambiente:</span>
              <select
                value={selectedSoundId}
                onChange={(e) => setSelectedSoundId(e.target.value)}
                disabled={isActive}
                className="bg-gray-50 border border-gray-200 rounded-lg px-3 py-1 focus:outline-none focus:ring-1 focus:ring-indigo-500 disabled:opacity-50"
              >
                {availableSounds.map((sound) => (
                  <option key={sound.id} value={sound.id}>
                    {sound.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        )}

        {/* Instructions */}
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-3">
            Como praticar
          </h3>
          <div className="space-y-2 text-gray-600">
            <p>• Sente-se confortavelmente com as costas retas</p>
            <p>• Coloque uma mão no peito e outra no abdômen</p>
            <p>• Respire pelo nariz, expandindo o abdômen</p>
            <p>• Siga o ritmo visual do círculo</p>
            <p>• Pratique por 5-10 minutos diariamente</p>
          </div>
        </div>
      </div>
    </div>
  );
}