import React, { useState, useEffect } from 'react';
import { RefreshCw, Heart } from 'lucide-react';

const quotes = [
  {
    text: "A paz não pode ser mantida pela força; só pode ser alcançada pelo entendimento.",
    author: "Albert Einstein"
  },
  {
    text: "Você tem poder sobre sua mente - não sobre eventos externos. Perceba isso, e você encontrará força.",
    author: "Marco Aurélio"
  },
  {
    text: "A felicidade não é algo pronto. Ela vem de suas próprias ações.",
    author: "Dalai Lama"
  },
  {
    text: "O presente é o único momento sobre o qual temos domínio.",
    author: "Thich Nhat Hanh"
  },
  {
    text: "Calma é a capacidade de não reagir.",
    author: "Provérbio Budista"
  },
  {
    text: "A mente é tudo. O que você pensa, você se torna.",
    author: "Buda"
  },
  {
    text: "Não deixe que o comportamento dos outros destrua sua paz interior.",
    author: "Dalai Lama"
  },
  {
    text: "A respiração é a ponte que conecta a vida à consciência.",
    author: "Thich Nhat Hanh"
  },
  {
    text: "Onde quer que você esteja, esteja lá totalmente.",
    author: "Eckhart Tolle"
  },
  {
    text: "A meditação não é uma fuga da vida, mas uma preparação para ela.",
    author: "Provérbio Tibetano"
  }
];

export default function DailyQuote() {
  const [currentQuote, setCurrentQuote] = useState(0);
  const [isLiked, setIsLiked] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    // Set a random quote on component mount
    setCurrentQuote(Math.floor(Math.random() * quotes.length));
  }, []);

  const getNewQuote = () => {
    setIsAnimating(true);
    let newIndex;
    do {
      newIndex = Math.floor(Math.random() * quotes.length);
    } while (newIndex === currentQuote);
    
    setTimeout(() => {
      setCurrentQuote(newIndex);
      setIsLiked(false);
      setIsAnimating(false);
    }, 300);
  };

  const quote = quotes[currentQuote];

  return (
    <div className="bg-white/90 backdrop-blur-sm rounded-2xl sm:rounded-3xl shadow-2xl p-6 sm:p-8 lg:p-10 mb-8 sm:mb-12 relative overflow-hidden border border-white/20">
      <div className="absolute top-0 left-0 w-full h-2 sm:h-3 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 rounded-t-2xl sm:rounded-t-3xl"></div>
      
      <div className="text-center">
        <h3 className="text-xl sm:text-2xl font-bold text-gray-800 mb-6 sm:mb-8 tracking-tight">
          Reflexão do Dia
        </h3>
        
        <blockquote className={`text-lg sm:text-2xl lg:text-3xl font-light text-gray-700 mb-6 sm:mb-8 leading-relaxed italic px-4 transition-all duration-300 ${
          isAnimating ? 'opacity-0 transform scale-95' : 'opacity-100 transform scale-100'
        }`}>
          "{quote.text}"
        </blockquote>
        
        <cite className={`text-base sm:text-lg lg:text-xl text-indigo-600 font-semibold transition-all duration-300 ${
          isAnimating ? 'opacity-0 transform translate-y-2' : 'opacity-100 transform translate-y-0'
        }`}>
          — {quote.author}
        </cite>
        
        <div className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-6 mt-6 sm:mt-8 lg:mt-10">
          <button
            onClick={() => setIsLiked(!isLiked)}
            className={`flex items-center space-x-2 sm:space-x-3 px-4 sm:px-6 py-2 sm:py-3 rounded-xl sm:rounded-2xl transition-all duration-300 transform hover:scale-105 shadow-lg text-sm sm:text-base active:scale-95 ${
              isLiked 
                ? 'bg-gradient-to-r from-red-500 to-pink-500 text-white shadow-xl' 
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            <Heart className={`w-5 h-5 sm:w-6 sm:h-6 ${isLiked ? 'fill-current' : ''}`} />
            <span className="font-semibold">{isLiked ? 'Curtido' : 'Curtir'}</span>
          </button>
          
          <button
            onClick={getNewQuote}
            className={`flex items-center space-x-2 sm:space-x-3 px-4 sm:px-6 py-2 sm:py-3 bg-gradient-to-r from-indigo-500 to-purple-500 text-white rounded-xl sm:rounded-2xl hover:from-indigo-600 hover:to-purple-600 transition-all duration-300 transform hover:scale-105 shadow-lg text-sm sm:text-base active:scale-95 ${
              isAnimating ? 'animate-spin' : ''
            }`}
            disabled={isAnimating}
          >
            <RefreshCw className="w-5 h-5 sm:w-6 sm:h-6" />
            <span className="font-semibold">Nova Reflexão</span>
          </button>
        </div>
      </div>
    </div>
  );
}