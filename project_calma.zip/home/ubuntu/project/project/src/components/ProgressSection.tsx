import React, { useState, useEffect } from 'react';
import { TrendingUp, Clock, Calendar, Award, Target, Flame, BarChart3, Star } from 'lucide-react';
import { getUserProgress, type UserProgress } from '../lib/supabase';
import { translations, type Language } from '../lib/translations';

interface ProgressSectionProps {
  language: Language;
  user: any;
}

export default function ProgressSection({ language, user }: ProgressSectionProps) {
  const [progress, setProgress] = useState<UserProgress | null>(null);
  const [loading, setLoading] = useState(true);
  const t = translations[language];

  useEffect(() => {
    if (user) {
      loadProgress();
    }
  }, [user]);

  const loadProgress = async () => {
    try {
      const userProgress = await getUserProgress(user.id);
      setProgress(userProgress);
    } catch (error) {
      console.error('Error loading progress:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatTime = (minutes: number) => {
    if (minutes < 60) {
      return `${minutes} ${t.minutes}`;
    }
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    return `${hours}h ${remainingMinutes}m`;
  };

  const getStreakMessage = (streak: number) => {
    if (streak === 0) return 'Comece sua jornada hoje!';
    if (streak === 1) return 'Ótimo começo! Continue assim.';
    if (streak < 7) return 'Você está criando um hábito!';
    if (streak < 30) return 'Incrível! Você está no caminho certo.';
    return 'Parabéns! Você é um verdadeiro praticante!';
  };

  const getProgressLevel = (sessions: number) => {
    if (sessions < 5) return { level: 'Iniciante', color: 'from-green-400 to-green-600', progress: (sessions / 5) * 100 };
    if (sessions < 20) return { level: 'Praticante', color: 'from-blue-400 to-blue-600', progress: ((sessions - 5) / 15) * 100 };
    if (sessions < 50) return { level: 'Experiente', color: 'from-purple-400 to-purple-600', progress: ((sessions - 20) / 30) * 100 };
    if (sessions < 100) return { level: 'Avançado', color: 'from-orange-400 to-orange-600', progress: ((sessions - 50) / 50) * 100 };
    return { level: 'Mestre', color: 'from-yellow-400 to-yellow-600', progress: 100 };
  };

  if (!user) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="bg-white/90 backdrop-blur-sm rounded-2xl sm:rounded-3xl shadow-2xl p-6 sm:p-8 border border-white/20 text-center">
          <div className="w-16 h-16 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
            <TrendingUp className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-4">
            {t.progressTitle}
          </h2>
          <p className="text-gray-600 mb-6">
            Faça login para acompanhar seu progresso de bem-estar e ver suas estatísticas de meditação.
          </p>
          <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-6 border border-indigo-100">
            <h3 className="text-lg font-semibold text-gray-800 mb-3">O que você pode acompanhar:</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm text-gray-600">
              <div className="flex items-center space-x-2">
                <Calendar className="w-4 h-4 text-indigo-500" />
                <span>Sessões de meditação realizadas</span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-indigo-500" />
                <span>Tempo total de prática</span>
              </div>
              <div className="flex items-center space-x-2">
                <Flame className="w-4 h-4 text-indigo-500" />
                <span>Sequência de dias consecutivos</span>
              </div>
              <div className="flex items-center space-x-2">
                <Award className="w-4 h-4 text-indigo-500" />
                <span>Nível de experiência</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="bg-white/90 backdrop-blur-sm rounded-2xl sm:rounded-3xl shadow-2xl p-6 sm:p-8 border border-white/20">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-1/3 mx-auto mb-6"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-32 bg-gray-200 rounded-xl"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  const levelInfo = getProgressLevel(progress?.total_sessions || 0);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6">
      <div className="bg-white/90 backdrop-blur-sm rounded-2xl sm:rounded-3xl shadow-2xl p-6 sm:p-8 border border-white/20">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
            <TrendingUp className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-2">
            {t.progressTitle}
          </h2>
          <p className="text-gray-600">
            Acompanhe sua jornada de bem-estar e mindfulness
          </p>
        </div>

        {/* User Level */}
        <div className="mb-8 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-2xl p-6 border border-indigo-100">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-xl font-bold text-gray-800">{levelInfo.level}</h3>
              <p className="text-gray-600">Seu nível atual de prática</p>
            </div>
            <div className={`w-12 h-12 bg-gradient-to-r ${levelInfo.color} rounded-xl flex items-center justify-center shadow-lg`}>
              <Star className="w-6 h-6 text-white" />
            </div>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3 mb-2">
            <div 
              className={`h-3 bg-gradient-to-r ${levelInfo.color} rounded-full transition-all duration-500`}
              style={{ width: `${levelInfo.progress}%` }}
            ></div>
          </div>
          <p className="text-sm text-gray-600">
            {levelInfo.progress < 100 
              ? `${Math.round(levelInfo.progress)}% para o próximo nível`
              : 'Nível máximo alcançado! 🎉'
            }
          </p>
        </div>

        {/* Statistics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {/* Total Sessions */}
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl p-6 border border-blue-200">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg">
                <Calendar className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold text-blue-700">
                {progress?.total_sessions || 0}
              </span>
            </div>
            <h3 className="font-semibold text-blue-800 mb-1">{t.totalSessions}</h3>
            <p className="text-sm text-blue-600">Sessões completadas</p>
          </div>

          {/* Total Time */}
          <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-2xl p-6 border border-green-200">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-green-600 rounded-xl flex items-center justify-center shadow-lg">
                <Clock className="w-6 h-6 text-white" />
              </div>
              <span className="text-lg font-bold text-green-700">
                {formatTime(progress?.total_time || 0)}
              </span>
            </div>
            <h3 className="font-semibold text-green-800 mb-1">{t.totalTime}</h3>
            <p className="text-sm text-green-600">Tempo de prática</p>
          </div>

          {/* Current Streak */}
          <div className="bg-gradient-to-br from-orange-50 to-orange-100 rounded-2xl p-6 border border-orange-200">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-orange-600 rounded-xl flex items-center justify-center shadow-lg">
                <Flame className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold text-orange-700">
                {progress?.current_streak || 0}
              </span>
            </div>
            <h3 className="font-semibold text-orange-800 mb-1">{t.currentStreak}</h3>
            <p className="text-sm text-orange-600">{t.days} consecutivos</p>
          </div>

          {/* Longest Streak */}
          <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-2xl p-6 border border-purple-200">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                <Award className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold text-purple-700">
                {progress?.longest_streak || 0}
              </span>
            </div>
            <h3 className="font-semibold text-purple-800 mb-1">{t.longestStreak}</h3>
            <p className="text-sm text-purple-600">Melhor sequência</p>
          </div>
        </div>

        {/* Motivation Section */}
        <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-2xl p-6 border border-indigo-100">
          <div className="flex items-center space-x-4 mb-4">
            <div className="w-12 h-12 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
              <Target className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-gray-800">Mensagem Motivacional</h3>
              <p className="text-indigo-600 font-medium">
                {getStreakMessage(progress?.current_streak || 0)}
              </p>
            </div>
          </div>
          
          {progress?.current_streak === 0 && (
            <div className="mt-4 p-4 bg-white rounded-lg border border-indigo-200">
              <p className="text-sm text-gray-600 mb-2">
                <strong>Dica:</strong> Comece com apenas 5 minutos de meditação por dia. 
                A consistência é mais importante que a duração!
              </p>
            </div>
          )}
        </div>

        {/* Weekly Goal */}
        <div className="mt-8 bg-gradient-to-r from-emerald-50 to-teal-50 rounded-2xl p-6 border border-emerald-100">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-bold text-gray-800">Meta Semanal</h3>
              <p className="text-gray-600">Pratique pelo menos 3 vezes esta semana</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center shadow-lg">
              <BarChart3 className="w-6 h-6 text-white" />
            </div>
          </div>
          
          {/* Weekly progress would be calculated based on last 7 days */}
          <div className="w-full bg-gray-200 rounded-full h-3 mb-2">
            <div 
              className="h-3 bg-gradient-to-r from-emerald-500 to-teal-600 rounded-full transition-all duration-500"
              style={{ width: `${Math.min(((progress?.current_streak || 0) / 7) * 100, 100)}%` }}
            ></div>
          </div>
          <p className="text-sm text-gray-600">
            {progress?.current_streak || 0} de 7 dias esta semana
          </p>
        </div>
      </div>
    </div>
  );
}

