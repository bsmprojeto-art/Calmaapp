import React, { useState } from 'react';
import { Star, Send, Heart, ThumbsUp, MessageCircle } from 'lucide-react';

interface Review {
  id: string;
  name: string;
  rating: number;
  comment: string;
  date: string;
  helpful: number;
}

export default function ReviewsSection() {
  const [reviews, setReviews] = useState<Review[]>([
    {
      id: '1',
      name: 'Maria Silva',
      rating: 5,
      comment: 'Este app mudou minha vida! As técnicas de respiração me ajudaram muito com a ansiedade. Recomendo para todos que buscam paz interior.',
      date: '2024-01-15',
      helpful: 12
    },
    {
      id: '2',
      name: 'João Santos',
      rating: 5,
      comment: 'Excelente! Uso todos os dias antes de dormir. A meditação guiada é perfeita e o livro tem conteúdo muito rico.',
      date: '2024-01-14',
      helpful: 8
    },
    {
      id: '3',
      name: 'Ana Costa',
      rating: 4,
      comment: 'Muito bom app! Me ajuda a relaxar depois de dias estressantes. O design é lindo e fácil de usar.',
      date: '2024-01-13',
      helpful: 5
    }
  ]);

  const [newReview, setNewReview] = useState({
    name: '',
    rating: 5,
    comment: ''
  });

  const [showForm, setShowForm] = useState(false);

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (newReview.name.trim() && newReview.comment.trim()) {
      const review: Review = {
        id: Date.now().toString(),
        name: newReview.name,
        rating: newReview.rating,
        comment: newReview.comment,
        date: new Date().toISOString().split('T')[0],
        helpful: 0
      };
      setReviews([review, ...reviews]);
      setNewReview({ name: '', rating: 5, comment: '' });
      setShowForm(false);
    }
  };

  const handleHelpful = (reviewId: string) => {
    setReviews(reviews.map(review => 
      review.id === reviewId 
        ? { ...review, helpful: review.helpful + 1 }
        : review
    ));
  };

  const renderStars = (rating: number, interactive = false, onRatingChange?: (rating: number) => void) => {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type={interactive ? "button" : undefined}
            onClick={interactive && onRatingChange ? () => onRatingChange(star) : undefined}
            className={`${interactive ? 'cursor-pointer hover:scale-110' : 'cursor-default'} transition-transform duration-200`}
            disabled={!interactive}
          >
            <Star
              className={`w-5 h-5 ${
                star <= rating
                  ? 'text-yellow-400 fill-current'
                  : 'text-gray-300'
              }`}
            />
          </button>
        ))}
      </div>
    );
  };

  const averageRating = reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length;

  return (
    <div className="max-w-4xl mx-auto space-y-6 sm:space-y-8">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-800 mb-4 tracking-tight">
          Avaliações da Comunidade
        </h2>
        <p className="text-base sm:text-lg text-gray-600 max-w-2xl mx-auto leading-relaxed px-4">
          Veja o que outras pessoas estão dizendo sobre sua jornada de bem-estar
        </p>
      </div>

      {/* Stats */}
      <div className="bg-white/90 backdrop-blur-sm rounded-2xl sm:rounded-3xl shadow-xl p-6 sm:p-8 border border-white/20">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center">
          <div>
            <div className="text-3xl sm:text-4xl font-bold text-gray-800 mb-2">
              {averageRating.toFixed(1)}
            </div>
            <div className="flex justify-center mb-2">
              {renderStars(Math.round(averageRating))}
            </div>
            <div className="text-sm text-gray-600">Média geral</div>
          </div>
          
          <div>
            <div className="text-3xl sm:text-4xl font-bold text-gray-800 mb-2">
              {reviews.length}
            </div>
            <div className="flex justify-center mb-2">
              <MessageCircle className="w-6 h-6 text-indigo-600" />
            </div>
            <div className="text-sm text-gray-600">Avaliações</div>
          </div>
          
          <div>
            <div className="text-3xl sm:text-4xl font-bold text-gray-800 mb-2">
              98%
            </div>
            <div className="flex justify-center mb-2">
              <Heart className="w-6 h-6 text-pink-600 fill-current" />
            </div>
            <div className="text-sm text-gray-600">Recomendam</div>
          </div>
        </div>
      </div>

      {/* Add Review Button */}
      <div className="text-center">
        <button
          onClick={() => setShowForm(!showForm)}
          className="inline-flex items-center gap-3 px-6 sm:px-8 py-3 sm:py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl sm:rounded-2xl font-semibold hover:from-indigo-700 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg text-sm sm:text-base"
        >
          <Star className="w-5 h-5" />
          {showForm ? 'Cancelar' : 'Deixar Avaliação'}
        </button>
      </div>

      {/* Review Form */}
      {showForm && (
        <div className="bg-white/90 backdrop-blur-sm rounded-2xl sm:rounded-3xl shadow-xl p-6 sm:p-8 border border-white/20">
          <h3 className="text-xl sm:text-2xl font-bold text-gray-800 mb-6">
            Compartilhe sua experiência
          </h3>
          
          <form onSubmit={handleSubmitReview} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Seu nome
              </label>
              <input
                type="text"
                value={newReview.name}
                onChange={(e) => setNewReview({ ...newReview, name: e.target.value })}
                className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200 text-sm sm:text-base"
                placeholder="Digite seu nome"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Sua avaliação
              </label>
              <div className="flex items-center gap-4">
                {renderStars(newReview.rating, true, (rating) => 
                  setNewReview({ ...newReview, rating })
                )}
                <span className="text-sm text-gray-600">
                  {newReview.rating} de 5 estrelas
                </span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Seu comentário
              </label>
              <textarea
                value={newReview.comment}
                onChange={(e) => setNewReview({ ...newReview, comment: e.target.value })}
                rows={4}
                className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200 resize-none text-sm sm:text-base"
                placeholder="Conte como o app te ajudou em sua jornada de bem-estar..."
                required
              />
            </div>

            <button
              type="submit"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-3 px-6 sm:px-8 py-3 sm:py-4 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-xl font-semibold hover:from-emerald-700 hover:to-teal-700 transition-all duration-300 transform hover:scale-105 shadow-lg text-sm sm:text-base"
            >
              <Send className="w-5 h-5" />
              Enviar Avaliação
            </button>
          </form>
        </div>
      )}

      {/* Reviews List */}
      <div className="space-y-4 sm:space-y-6">
        {reviews.map((review) => (
          <div
            key={review.id}
            className="bg-white/90 backdrop-blur-sm rounded-2xl sm:rounded-3xl shadow-xl p-6 sm:p-8 border border-white/20"
          >
            <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 mb-4">
              <div className="flex-1">
                <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 mb-2">
                  <h4 className="font-semibold text-gray-800 text-base sm:text-lg">
                    {review.name}
                  </h4>
                  <div className="flex items-center gap-2">
                    {renderStars(review.rating)}
                    <span className="text-sm text-gray-600">
                      {new Date(review.date).toLocaleDateString('pt-BR')}
                    </span>
                  </div>
                </div>
              </div>
            </div>
            
            <p className="text-gray-700 leading-relaxed mb-4 text-sm sm:text-base">
              {review.comment}
            </p>
            
            <div className="flex items-center justify-between">
              <button
                onClick={() => handleHelpful(review.id)}
                className="flex items-center gap-2 text-gray-600 hover:text-indigo-600 transition-colors duration-200 text-sm"
              >
                <ThumbsUp className="w-4 h-4" />
                <span>Útil ({review.helpful})</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Call to Action */}
      <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-2xl sm:rounded-3xl p-6 sm:p-8 border border-indigo-200 text-center">
        <h3 className="text-xl sm:text-2xl font-bold text-gray-800 mb-4">
          Sua opinião é importante! 💜
        </h3>
        <p className="text-gray-600 mb-6 text-sm sm:text-base leading-relaxed">
          Ajude outras pessoas a descobrirem este app compartilhando sua experiência. 
          Cada avaliação nos motiva a continuar desenvolvendo ferramentas para o bem-estar mental.
        </p>
        {!showForm && (
          <button
            onClick={() => setShowForm(true)}
            className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl font-semibold hover:from-indigo-700 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg text-sm sm:text-base"
          >
            <Star className="w-5 h-5" />
            Avaliar Agora
          </button>
        )}
      </div>
    </div>
  );
}