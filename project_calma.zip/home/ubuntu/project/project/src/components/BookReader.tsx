import React, { useState, useEffect } from 'react';
import { BookOpen, ChevronLeft, ChevronRight, Download, Heart } from 'lucide-react';

interface BookChapter {
  id: string;
  title: string;
  content: string;
  order: number;
}

const BookReader: React.FC = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [fontSize, setFontSize] = useState(16);
  const [bookChapters, setBookChapters] = useState<BookChapter[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadBookChapters = async () => {
      try {
        const response = await fetch('/data/book_chapters.json');
        const chapters = await response.json();
        setBookChapters(chapters.sort((a: BookChapter, b: BookChapter) => a.order - b.order));
        setLoading(false);
      } catch (error) {
        console.error('Erro ao carregar capítulos do livro:', error);
        setLoading(false);
      }
    };

    loadBookChapters();
  }, []);

  const totalPages = bookChapters.length;

  const nextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const prevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const downloadBook = () => {
    const bookText = bookChapters.map((chapter, index) => 
      `${chapter.title}\n\n${chapter.content}\n\n${'='.repeat(50)}\n\n`
    ).join('');
    
    const blob = new Blob([bookText], { type: 'text/plain; charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'calma-livro-completo.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const formatContent = (content: string) => {
    return content.split('\n').map((paragraph, index) => {
      if (paragraph.trim() === '') return null;
      
      // Detectar títulos (linhas que começam com **)
      if (paragraph.startsWith('**') && paragraph.endsWith('**')) {
        return (
          <h3 key={index} className="text-lg font-bold text-gray-800 mt-6 mb-3">
            {paragraph.replace(/\*\*/g, '')}
          </h3>
        );
      }
      
      // Detectar listas (linhas que começam com •)
      if (paragraph.startsWith('•')) {
        return (
          <li key={index} className="ml-4 mb-2 text-gray-700">
            {paragraph.substring(1).trim()}
          </li>
        );
      }
      
      // Parágrafos normais
      return (
        <p key={index} className="mb-4 text-gray-700 leading-relaxed">
          {paragraph}
        </p>
      );
    }).filter(Boolean);
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="bg-white/90 backdrop-blur-sm rounded-3xl shadow-2xl p-8 border border-white/20">
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-teal-600 rounded-2xl flex items-center justify-center text-white shadow-lg mx-auto mb-4">
                <BookOpen className="w-6 h-6" />
              </div>
              <p className="text-gray-600">Carregando livro...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (bookChapters.length === 0) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="bg-white/90 backdrop-blur-sm rounded-3xl shadow-2xl p-8 border border-white/20">
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-teal-600 rounded-2xl flex items-center justify-center text-white shadow-lg mx-auto mb-4">
                <BookOpen className="w-6 h-6" />
              </div>
              <p className="text-gray-600">Erro ao carregar o livro. Tente novamente mais tarde.</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const currentChapter = bookChapters[currentPage - 1];

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="bg-white/90 backdrop-blur-sm rounded-3xl shadow-2xl p-8 border border-white/20">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-teal-600 rounded-2xl flex items-center justify-center text-white shadow-lg">
              <BookOpen className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-800">Calma</h1>
              <p className="text-gray-600">Um guia prático para encontrar paz interior</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <label className="text-sm text-gray-600">Tamanho da fonte:</label>
              <select 
                value={fontSize} 
                onChange={(e) => setFontSize(Number(e.target.value))}
                className="px-3 py-1 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <option value={14}>Pequena</option>
                <option value={16}>Normal</option>
                <option value={18}>Grande</option>
                <option value={20}>Muito Grande</option>
              </select>
            </div>
            <button
              onClick={downloadBook}
              className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-xl hover:from-emerald-600 hover:to-teal-700 transition-all duration-300 shadow-lg"
            >
              <Download className="w-4 h-4" />
              <span>Download</span>
            </button>
          </div>
        </div>

        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-800">{currentChapter.title}</h2>
            <span className="text-sm text-gray-500">Página {currentPage} de {totalPages}</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2 mb-6">
            <div 
              className="bg-gradient-to-r from-emerald-500 to-teal-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${(currentPage / totalPages) * 100}%` }}
            ></div>
          </div>
        </div>

        <div 
          className="prose prose-lg max-w-none mb-8 leading-relaxed"
          style={{ fontSize: `${fontSize}px`, lineHeight: '1.8' }}
        >
          {formatContent(currentChapter.content)}
        </div>

        <div className="flex items-center justify-between">
          <button
            onClick={prevPage}
            disabled={currentPage === 1}
            className={`flex items-center space-x-2 px-6 py-3 rounded-xl transition-all duration-300 ${
              currentPage === 1
                ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                : 'bg-gradient-to-r from-gray-500 to-gray-600 text-white hover:from-gray-600 hover:to-gray-700 shadow-lg'
            }`}
          >
            <ChevronLeft className="w-5 h-5" />
            <span>Página Anterior</span>
          </button>

          <div className="flex items-center space-x-2">
            <Heart className="w-5 h-5 text-red-500" />
            <span className="text-sm text-gray-600">Feito com amor para seu bem-estar</span>
          </div>

          <button
            onClick={nextPage}
            disabled={currentPage === totalPages}
            className={`flex items-center space-x-2 px-6 py-3 rounded-xl transition-all duration-300 ${
              currentPage === totalPages
                ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                : 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white hover:from-emerald-600 hover:to-teal-700 shadow-lg'
            }`}
          >
            <span>Próxima Página</span>
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default BookReader;

