import React, { useState, useEffect } from 'react';
import { Heart, Play, Pause, RotateCcw, Sparkles, Flower2, Sun, Moon } from 'lucide-react';
import { translations, type Language } from '../lib/translations';

interface PracticeProps {
  language: Language;
}

const practices = [
  {
    id: 1,
    title: 'Reconexão com o Coração',
    reflection: 'Pare por um momento. Respire fundo três vezes. Coloque uma mão no seu coração. Sinta as batidas. Que emoção está presente agora? Acolha-a com gentileza, como acolheria um amigo querido.',
    exercise: 'Feche os olhos e coloque ambas as mãos no coração. Respire profundamente 5 vezes. A cada respiração, envie amor e compaixão para si mesmo. Diga mentalmente: "Eu me aceito como sou neste momento".',
    duration: 3,
    icon: <Heart className="w-6 h-6" />
  },
  {
    id: 2,
    title: 'Ancoragem no Presente',
    reflection: 'Observe ao seu redor. Nomeie 5 coisas que você pode ver, 4 que pode tocar, 3 que pode ouvir, 2 que pode cheirar e 1 que pode saborear. Você está aqui, agora, e isso é suficiente.',
    exercise: 'Sente-se confortavelmente. Respire naturalmente. A cada expiração, solte as tensões do dia. A cada inspiração, traga presença para este momento. Continue por 2 minutos.',
    duration: 2,
    icon: <Sun className="w-6 h-6" />
  },
  {
    id: 3,
    title: 'Abraço Interior',
    reflection: 'Imagine que você pode se abraçar por dentro. Que palavras de carinho você diria para si mesmo? Que conforto você ofereceria? Você merece toda a gentileza que dá aos outros.',
    exercise: 'Cruze os braços sobre o peito, como se estivesse se abraçando. Respire devagar e profundamente. A cada respiração, aperte o abraço suavemente. Sinta o calor e o conforto que você pode oferecer a si mesmo.',
    duration: 4,
    icon: <Flower2 className="w-6 h-6" />
  },
  {
    id: 4,
    title: 'Liberação Noturna',
    reflection: 'O dia está terminando. Que emoções você carregou hoje? Quais você gostaria de liberar? Permita-se sentir sem julgamento, depois deixe ir com gratidão pelo que aprendeu.',
    exercise: 'Deite-se confortavelmente. Tensione todos os músculos do corpo por 5 segundos, depois relaxe completamente. Repita 3 vezes. A cada relaxamento, libere as tensões emocionais do dia.',
    duration: 5,
    icon: <Moon className="w-6 h-6" />
  }
];

export default function Practice({ language }: PracticeProps) {
  const [showPractice, setShowPractice] = useState(false);
  const [currentPractice, setCurrentPractice] = useState(practices[0]);
  const [isActive, setIsActive] = useState(false);
  const [timeLeft, setTimeLeft] = useState(0);
  const [step, setStep] = useState<'reflection' | 'exercise'>('reflection');

  const t = translations[language];

  useEffect(() => {
    // Select practice based on time of day
    const hour = new Date().getHours();
    let practiceIndex = 0;
    
    if (hour >= 6 && hour < 12) {
      practiceIndex = 1; // Morning - Ancoragem no Presente
    } else if (hour >= 12 && hour < 18) {
      practiceIndex = 0; // Afternoon - Reconexão com o Coração
    } else if (hour >= 18 && hour < 22) {
      practiceIndex = 2; // Evening - Abraço Interior
    } else {
      practiceIndex = 3; // Night - Liberação Noturna
    }
    
    setCurrentPractice(practices[practiceIndex]);
  }, []);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(timeLeft - 1);
      }, 1000);
    } else if (timeLeft === 0 && isActive) {
      setIsActive(false);
      // Auto-advance to exercise after reflection
      if (step === 'reflection') {
        setStep('exercise');
        setTimeLeft(currentPractice.duration * 60);
      }
    }
    
    return () => clearInterval(interval);
  }, [isActive, timeLeft, step, currentPractice.duration]);

  const startPractice = () => {
    setShowPractice(true);
    setStep('reflection');
    setTimeLeft(120); // 2 minutes for reflection
    setIsActive(true);
  };

  const toggleTimer = () => {
    setIsActive(!isActive);
  };

  const resetPractice = () => {
    setIsActive(false);
    setStep('reflection');
    setTimeLeft(120);
    setShowPractice(false);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getRandomPractice = () => {
    const randomIndex = Math.floor(Math.random() * practices.length);
    setCurrentPractice(practices[randomIndex]);
    setStep('reflection');
    setTimeLeft(120);
    setIsActive(false);
  };

  if (!showPractice) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="bg-white/90 backdrop-blur-sm rounded-2xl sm:rounded-3xl shadow-2xl p-6 sm:p-8 border border-white/20">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-r from-pink-500 to-rose-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
              <Heart className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-4">
              {t.practiceTitle}
            </h2>
            <p className="text-gray-600 text-lg mb-6">
              {t.practiceDescription}
            </p>
          </div>

          {/* Current Practice Preview */}
          <div className="bg-gradient-to-r from-pink-50 to-rose-50 rounded-2xl p-6 sm:p-8 border border-pink-100 mb-8">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-pink-500 to-rose-600 rounded-xl flex items-center justify-center text-white">
                {currentPractice.icon}
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-800">{currentPractice.title}</h3>
                <p className="text-pink-600 text-sm">Prática recomendada para este momento</p>
              </div>
            </div>
            
            <p className="text-gray-700 mb-6 leading-relaxed">
              {currentPractice.reflection.substring(0, 150)}...
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={startPractice}
                className="flex-1 bg-gradient-to-r from-pink-600 to-rose-600 text-white py-4 px-6 rounded-xl font-semibold hover:from-pink-700 hover:to-rose-700 focus:ring-2 focus:ring-pink-500 focus:ring-offset-2 transition-all duration-200 transform hover:scale-105 flex items-center justify-center space-x-2"
              >
                <Play className="w-5 h-5" />
                <span>{t.startPractice}</span>
              </button>
              
              <button
                onClick={getRandomPractice}
                className="flex-1 bg-white text-pink-600 py-4 px-6 rounded-xl font-semibold border-2 border-pink-200 hover:bg-pink-50 focus:ring-2 focus:ring-pink-500 focus:ring-offset-2 transition-all duration-200 transform hover:scale-105 flex items-center justify-center space-x-2"
              >
                <Sparkles className="w-5 h-5" />
                <span>Outra Prática</span>
              </button>
            </div>
          </div>

          {/* Benefits */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-6 border border-blue-200">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg flex items-center justify-center mb-4">
                <Heart className="w-5 h-5 text-white" />
              </div>
              <h3 className="font-semibold text-blue-800 mb-2">Conexão Emocional</h3>
              <p className="text-blue-700 text-sm">
                Reconecte-se com suas emoções de forma saudável e compassiva.
              </p>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-xl p-6 border border-green-200">
              <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-green-600 rounded-lg flex items-center justify-center mb-4">
                <Sun className="w-5 h-5 text-white" />
              </div>
              <h3 className="font-semibold text-green-800 mb-2">Presença Plena</h3>
              <p className="text-green-700 text-sm">
                Cultive a presença no momento atual com exercícios simples.
              </p>
            </div>

            <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl p-6 border border-purple-200">
              <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg flex items-center justify-center mb-4">
                <Flower2 className="w-5 h-5 text-white" />
              </div>
              <h3 className="font-semibold text-purple-800 mb-2">Autocompaixão</h3>
              <p className="text-purple-700 text-sm">
                Desenvolva uma relação mais gentil e amorosa consigo mesmo.
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6">
      <div className="bg-white/90 backdrop-blur-sm rounded-2xl sm:rounded-3xl shadow-2xl p-6 sm:p-8 border border-white/20">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-r from-pink-500 to-rose-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
            {currentPractice.icon}
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-2">
            {currentPractice.title}
          </h2>
          <div className="flex items-center justify-center space-x-4 text-sm text-gray-600">
            <span className={`px-3 py-1 rounded-full ${
              step === 'reflection' 
                ? 'bg-pink-100 text-pink-700 border border-pink-200' 
                : 'bg-gray-100 text-gray-600'
            }`}>
              1. Reflexão
            </span>
            <span className={`px-3 py-1 rounded-full ${
              step === 'exercise' 
                ? 'bg-pink-100 text-pink-700 border border-pink-200' 
                : 'bg-gray-100 text-gray-600'
            }`}>
              2. Exercício
            </span>
          </div>
        </div>

        {/* Timer */}
        <div className="text-center mb-8">
          <div className="w-32 h-32 mx-auto relative mb-4">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="45"
                stroke="currentColor"
                strokeWidth="4"
                fill="none"
                className="text-gray-200"
              />
              <circle
                cx="50"
                cy="50"
                r="45"
                stroke="currentColor"
                strokeWidth="4"
                fill="none"
                strokeDasharray={`${2 * Math.PI * 45}`}
                strokeDashoffset={`${2 * Math.PI * 45 * (timeLeft / (step === 'reflection' ? 120 : currentPractice.duration * 60))}`}
                className="text-pink-500 transition-all duration-1000 ease-linear"
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-2xl font-bold text-gray-800">
                {formatTime(timeLeft)}
              </span>
            </div>
          </div>

          <div className="flex justify-center space-x-4">
            <button
              onClick={toggleTimer}
              className="flex items-center justify-center w-12 h-12 bg-gradient-to-r from-pink-600 to-rose-600 text-white rounded-full hover:from-pink-700 hover:to-rose-700 transition-all duration-200 shadow-lg transform hover:scale-110"
            >
              {isActive ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
            </button>
            <button
              onClick={resetPractice}
              className="flex items-center justify-center w-12 h-12 bg-gray-600 text-white rounded-full hover:bg-gray-700 transition-all duration-200 shadow-lg transform hover:scale-110"
            >
              <RotateCcw className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="bg-gradient-to-r from-pink-50 to-rose-50 rounded-2xl p-6 sm:p-8 border border-pink-100">
          {step === 'reflection' ? (
            <div>
              <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center space-x-2">
                <Sparkles className="w-5 h-5 text-pink-500" />
                <span>Momento de Reflexão</span>
              </h3>
              <p className="text-gray-700 leading-relaxed text-lg">
                {currentPractice.reflection}
              </p>
            </div>
          ) : (
            <div>
              <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center space-x-2">
                <Heart className="w-5 h-5 text-pink-500" />
                <span>Exercício Guiado</span>
              </h3>
              <p className="text-gray-700 leading-relaxed text-lg">
                {currentPractice.exercise}
              </p>
            </div>
          )}
        </div>

        {/* Manual Step Control */}
        <div className="mt-6 flex justify-center space-x-4">
          {step === 'reflection' && (
            <button
              onClick={() => {
                setStep('exercise');
                setTimeLeft(currentPractice.duration * 60);
                setIsActive(false);
              }}
              className="px-6 py-3 bg-white text-pink-600 rounded-lg font-semibold border-2 border-pink-200 hover:bg-pink-50 transition-all duration-200"
            >
              Pular para Exercício
            </button>
          )}
          
          <button
            onClick={getRandomPractice}
            className="px-6 py-3 bg-white text-gray-600 rounded-lg font-semibold border-2 border-gray-200 hover:bg-gray-50 transition-all duration-200"
          >
            Trocar Prática
          </button>
        </div>
      </div>
    </div>
  );
}

