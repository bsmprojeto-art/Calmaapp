import React, { useState, useEffect } from 'react';
import { Calendar, TrendingUp, Award, Target, Clock, Brain } from 'lucide-react';

interface SessionData {
  date: string;
  type: 'meditation' | 'breathing' | 'technique';
  duration: number; // in minutes
  completed: boolean;
}

interface Stats {
  totalSessions: number;
  totalMinutes: number;
  streak: number;
  weeklyGoal: number;
  weeklyProgress: number;
}

export default function ProgressTracker() {
  const [sessions, setSessions] = useState<SessionData[]>([]);
  const [stats, setStats] = useState<Stats>({
    totalSessions: 0,
    totalMinutes: 0,
    streak: 0,
    weeklyGoal: 7,
    weeklyProgress: 0
  });

  // Simulate some data for demonstration
  useEffect(() => {
    const mockSessions: SessionData[] = [
      { date: '2024-01-15', type: 'meditation', duration: 10, completed: true },
      { date: '2024-01-14', type: 'breathing', duration: 5, completed: true },
      { date: '2024-01-13', type: 'technique', duration: 15, completed: true },
      { date: '2024-01-12', type: 'meditation', duration: 20, completed: true },
      { date: '2024-01-11', type: 'breathing', duration: 8, completed: true },
    ];

    setSessions(mockSessions);

    // Calculate stats
    const totalSessions = mockSessions.filter(s => s.completed).length;
    const totalMinutes = mockSessions.reduce((sum, s) => s.completed ? sum + s.duration : sum, 0);
    const streak = calculateStreak(mockSessions);
    const weeklyProgress = getWeeklyProgress(mockSessions);

    setStats({
      totalSessions,
      totalMinutes,
      streak,
      weeklyGoal: 7,
      weeklyProgress
    });
  }, []);

  const calculateStreak = (sessions: SessionData[]): number => {
    // Simple streak calculation - consecutive days with sessions
    const sortedSessions = sessions
      .filter(s => s.completed)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    let streak = 0;
    let currentDate = new Date();
    
    for (const session of sortedSessions) {
      const sessionDate = new Date(session.date);
      const diffDays = Math.floor((currentDate.getTime() - sessionDate.getTime()) / (1000 * 60 * 60 * 24));
      
      if (diffDays === streak) {
        streak++;
      } else {
        break;
      }
    }

    return streak;
  };

  const getWeeklyProgress = (sessions: SessionData[]): number => {
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

    const weekSessions = sessions.filter(s => 
      s.completed && new Date(s.date) >= oneWeekAgo
    );

    return weekSessions.length;
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'meditation': return <Brain className="w-4 h-4" />;
      case 'breathing': return <Clock className="w-4 h-4" />;
      case 'technique': return <Target className="w-4 h-4" />;
      default: return <Calendar className="w-4 h-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'meditation': return 'bg-purple-100 text-purple-800';
      case 'breathing': return 'bg-blue-100 text-blue-800';
      case 'technique': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeName = (type: string) => {
    switch (type) {
      case 'meditation': return 'Meditação';
      case 'breathing': return 'Respiração';
      case 'technique': return 'Técnica';
      default: return 'Sessão';
    }
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-800 mb-4">
          Seu Progresso
        </h2>
        <p className="text-lg text-gray-600">
          Acompanhe sua jornada de bem-estar e celebre suas conquistas
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard
          icon={<Calendar className="w-8 h-8" />}
          title="Total de Sessões"
          value={stats.totalSessions.toString()}
          subtitle="sessões completadas"
          color="from-blue-500 to-cyan-600"
        />
        <StatCard
          icon={<Clock className="w-8 h-8" />}
          title="Tempo Total"
          value={`${stats.totalMinutes} min`}
          subtitle="de prática"
          color="from-green-500 to-teal-600"
        />
        <StatCard
          icon={<TrendingUp className="w-8 h-8" />}
          title="Sequência Atual"
          value={`${stats.streak} dias`}
          subtitle="consecutivos"
          color="from-purple-500 to-indigo-600"
        />
        <StatCard
          icon={<Award className="w-8 h-8" />}
          title="Meta Semanal"
          value={`${stats.weeklyProgress}/${stats.weeklyGoal}`}
          subtitle="desta semana"
          color="from-pink-500 to-rose-600"
        />
      </div>

      {/* Weekly Progress */}
      <div className="bg-white rounded-2xl shadow-xl p-8 mb-8">
        <h3 className="text-2xl font-bold text-gray-800 mb-6">Progresso Semanal</h3>
        <div className="mb-4">
          <div className="flex justify-between text-sm text-gray-600 mb-2">
            <span>Meta: {stats.weeklyGoal} sessões</span>
            <span>{stats.weeklyProgress} de {stats.weeklyGoal} completadas</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div 
              className="bg-gradient-to-r from-indigo-500 to-purple-600 h-3 rounded-full transition-all duration-500"
              style={{ width: `${Math.min((stats.weeklyProgress / stats.weeklyGoal) * 100, 100)}%` }}
            ></div>
          </div>
        </div>
        
        {/* Weekly Calendar */}
        <div className="grid grid-cols-7 gap-2 mt-6">
          {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map((day, index) => (
            <div key={day} className="text-center">
              <div className="text-sm font-medium text-gray-600 mb-2">{day}</div>
              <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto ${
                index < stats.weeklyProgress 
                  ? 'bg-green-500 text-white' 
                  : 'bg-gray-200 text-gray-400'
              }`}>
                {index < stats.weeklyProgress ? '✓' : index + 1}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Sessions */}
      <div className="bg-white rounded-2xl shadow-xl p-8">
        <h3 className="text-2xl font-bold text-gray-800 mb-6">Sessões Recentes</h3>
        <div className="space-y-4">
          {sessions.slice(0, 5).map((session, index) => (
            <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-4">
                <div className={`p-2 rounded-full ${getTypeColor(session.type)}`}>
                  {getTypeIcon(session.type)}
                </div>
                <div>
                  <div className="font-medium text-gray-800">
                    {getTypeName(session.type)}
                  </div>
                  <div className="text-sm text-gray-600">
                    {new Date(session.date).toLocaleDateString('pt-BR')}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="font-medium text-gray-800">
                  {session.duration} min
                </div>
                <div className="text-sm text-green-600">
                  ✓ Concluída
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Achievements */}
      <div className="mt-8 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-2xl p-8">
        <h3 className="text-2xl font-bold text-gray-800 mb-6">Conquistas</h3>
        <div className="grid md:grid-cols-3 gap-6">
          <AchievementCard
            icon="🏆"
            title="Primeira Sessão"
            description="Completou sua primeira sessão de mindfulness"
            unlocked={stats.totalSessions >= 1}
          />
          <AchievementCard
            icon="🔥"
            title="Sequência de 3 Dias"
            description="Manteve uma sequência de 3 dias consecutivos"
            unlocked={stats.streak >= 3}
          />
          <AchievementCard
            icon="⭐"
            title="Meta Semanal"
            description="Atingiu a meta semanal de sessões"
            unlocked={stats.weeklyProgress >= stats.weeklyGoal}
          />
        </div>
      </div>
    </div>
  );
}

function StatCard({ 
  icon, 
  title, 
  value, 
  subtitle, 
  color 
}: {
  icon: React.ReactNode;
  title: string;
  value: string;
  subtitle: string;
  color: string;
}) {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className={`w-16 h-16 bg-gradient-to-r ${color} rounded-full flex items-center justify-center text-white mb-4`}>
        {icon}
      </div>
      <h3 className="text-lg font-semibold text-gray-800 mb-1">{title}</h3>
      <div className="text-3xl font-bold text-gray-800 mb-1">{value}</div>
      <p className="text-sm text-gray-600">{subtitle}</p>
    </div>
  );
}

function AchievementCard({
  icon,
  title,
  description,
  unlocked
}: {
  icon: string;
  title: string;
  description: string;
  unlocked: boolean;
}) {
  return (
    <div className={`p-6 rounded-xl ${unlocked ? 'bg-white shadow-lg' : 'bg-gray-100'}`}>
      <div className={`text-4xl mb-3 ${unlocked ? '' : 'grayscale opacity-50'}`}>
        {icon}
      </div>
      <h4 className={`text-lg font-semibold mb-2 ${unlocked ? 'text-gray-800' : 'text-gray-500'}`}>
        {title}
      </h4>
      <p className={`text-sm ${unlocked ? 'text-gray-600' : 'text-gray-400'}`}>
        {description}
      </p>
      {unlocked && (
        <div className="mt-3 text-sm font-medium text-green-600">
          ✓ Desbloqueada
        </div>
      )}
    </div>
  );
}