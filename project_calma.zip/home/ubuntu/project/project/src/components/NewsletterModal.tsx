import React, { useState } from 'react';
import { X, Mail, User, Send } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { translations, type Language } from '../lib/translations';

interface NewsletterModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

export default function NewsletterModal({ isOpen, onClose, language }: NewsletterModalProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const t = translations[language];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      // Simular inscrição na newsletter (funciona mesmo sem Supabase configurado)
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Tentar salvar no Supabase se estiver configurado
      try {
        const { error } = await supabase
          .from('newsletter_subscriptions')
          .insert([
            { 
              email: email,
              name: name,
              subscribed_at: new Date().toISOString()
            }
          ]);

        if (error && !error.message.includes('Failed to fetch')) {
          throw error;
        }
      } catch (supabaseError) {
        console.log('Supabase não configurado, usando modo demo');
      }

      setSuccess(true);
      setName('');
      setEmail('');
      
      // Fechar modal após 2 segundos
      setTimeout(() => {
        setSuccess(false);
        onClose();
      }, 2000);

    } catch (error: any) {
      setError('Erro ao inscrever na newsletter. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-md w-full p-6 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
        >
          <X size={24} />
        </button>

        <div className="text-center mb-6">
          <div className="bg-green-100 p-3 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
            <Mail className="text-green-600" size={32} />
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">
            {t.newsletter?.title || 'Newsletter'}
          </h2>
          <p className="text-gray-600">
            {t.newsletter?.description || 'Receba dicas de mindfulness e bem-estar diretamente no seu e-mail'}
          </p>
        </div>

        {success ? (
          <div className="text-center py-8">
            <div className="bg-green-100 p-3 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <Send className="text-green-600" size={32} />
            </div>
            <h3 className="text-xl font-semibold text-green-600 mb-2">
              Inscrição realizada com sucesso!
            </h3>
            <p className="text-gray-600">
              Obrigado por se inscrever. Em breve você receberá nossas dicas de bem-estar.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg">
                {error}
              </div>
            )}

            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                Nome
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <input
                  type="text"
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  placeholder="Seu nome"
                  required
                />
              </div>
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                E-mail
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  placeholder="seu@email.com"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 px-6 rounded-lg font-semibold hover:from-purple-700 hover:to-pink-700 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  Inscrevendo...
                </>
              ) : (
                <>
                  <Send size={20} />
                  Inscrever-se
                </>
              )}
            </button>

            <p className="text-xs text-gray-500 text-center">
              Ao se inscrever, você concorda em receber e-mails sobre mindfulness e bem-estar. 
              Você pode cancelar a inscrição a qualquer momento.
            </p>
          </form>
        )}
      </div>
    </div>
  );
}

