import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Play, Clock, Users } from 'lucide-react';

interface Technique {
  id: string;
  title: string;
  description: string;
  duration: string;
  difficulty: 'Iniciante' | 'Intermediário' | 'Avançado';
  category: string;
  steps: string[];
  benefits: string[];
}

const techniques: Technique[] = [
  {
    id: '1',
    title: 'Relaxamento Muscular Progressivo',
    description: 'Técnica que envolve tensionar e relaxar grupos musculares específicos',
    duration: '15-20 min',
    difficulty: 'Iniciante',
    category: 'Físico',
    steps: [
      'Deite-se confortavelmente em um local silencioso',
      'Comece pelos pés: contraia os músculos por 5 segundos',
      'Relaxe completamente e observe a sensação por 10 segundos',
      'Suba gradualmente: panturrilhas, coxas, abdômen, braços',
      'Termine com os músculos faciais',
      'Permaneça relaxado por alguns minutos'
    ],
    benefits: [
      'Reduz tensão muscular',
      'Diminui ansiedade',
      'Melhora qualidade do sono',
      'Aumenta consciência corporal'
    ]
  },
  {
    id: '2',
    title: 'Visualização Guiada',
    description: 'Use a imaginação para criar cenários relaxantes e peaceful',
    duration: '10-15 min',
    difficulty: 'Iniciante',
    category: 'Mental',
    steps: [
      'Encontre uma posição confortável e feche os olhos',
      'Respire profundamente algumas vezes',
      'Imagine um lugar que te traz paz (praia, floresta, montanha)',
      'Visualize todos os detalhes: cores, sons, cheiros',
      'Explore mentalmente este ambiente',
      'Permaneça neste estado por alguns minutos',
      'Retorne gradualmente ao presente'
    ],
    benefits: [
      'Reduz estresse mental',
      'Melhora criatividade',
      'Promove calma interior',
      'Desenvolve foco mental'
    ]
  },
  {
    id: '3',
    title: 'Técnica 5-4-3-2-1',
    description: 'Exercício de grounding que usa os cinco sentidos para reduzir ansiedade',
    duration: '5-10 min',
    difficulty: 'Iniciante',
    category: 'Mindfulness',
    steps: [
      'Identifique 5 coisas que você pode VER ao seu redor',
      'Identifique 4 coisas que você pode TOCAR',
      'Identifique 3 coisas que você pode OUVIR',
      'Identifique 2 coisas que você pode CHEIRAR',
      'Identifique 1 coisa que você pode SABOREAR',
      'Respire profundamente e observe como se sente'
    ],
    benefits: [
      'Reduz ansiedade rapidamente',
      'Traz foco ao momento presente',
      'Fácil de fazer em qualquer lugar',
      'Não requer preparação especial'
    ]
  },
  {
    id: '4',
    title: 'Meditação Body Scan',
    description: 'Varredura corporal para desenvolver consciência e relaxamento',
    duration: '20-30 min',
    difficulty: 'Intermediário',
    category: 'Mindfulness',
    steps: [
      'Deite-se confortavelmente de costas',
      'Comece focando na respiração natural',
      'Direcione atenção para o topo da cabeça',
      'Mova lentamente a atenção pelo corpo',
      'Observe sensações sem tentar mudá-las',
      'Continue até os dedos dos pés',
      'Termine observando o corpo como um todo'
    ],
    benefits: [
      'Aumenta consciência corporal',
      'Reduz tensão física',
      'Melhora qualidade do sono',
      'Desenvolve mindfulness'
    ]
  },
  {
    id: '5',
    title: 'Respiração Alternada (Nadi Shodhana)',
    description: 'Técnica de yoga que equilibra o sistema nervoso',
    duration: '10-15 min',
    difficulty: 'Intermediário',
    category: 'Respiração',
    steps: [
      'Sente-se confortavelmente com a coluna ereta',
      'Use o polegar direito para fechar a narina direita',
      'Inspire pela narina esquerda por 4 tempos',
      'Feche ambas as narinas e segure por 2 tempos',
      'Solte o polegar e expire pela direita por 4 tempos',
      'Inspire pela direita, segure, expire pela esquerda',
      'Continue alternando por 10-15 ciclos'
    ],
    benefits: [
      'Equilibra sistema nervoso',
      'Melhora concentração',
      'Reduz estresse',
      'Aumenta clareza mental'
    ]
  },
  {
    id: '6',
    title: 'Meditação Loving-Kindness',
    description: 'Cultiva compaixão e amor próprio através de frases positivas',
    duration: '15-20 min',
    difficulty: 'Avançado',
    category: 'Emocional',
    steps: [
      'Sente-se confortavelmente e feche os olhos',
      'Comece enviando amor para si mesmo',
      'Repita: "Que eu seja feliz, que eu seja saudável, que eu esteja em paz"',
      'Visualize alguém que você ama e repita as frases',
      'Estenda para uma pessoa neutra',
      'Inclua alguém com quem tem dificuldades',
      'Termine enviando amor para todos os seres'
    ],
    benefits: [
      'Aumenta autocompaixão',
      'Reduz sentimentos negativos',
      'Melhora relacionamentos',
      'Desenvolve empatia'
    ]
  }
];

export default function RelaxationTechniques() {
  const [expandedTechnique, setExpandedTechnique] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('Todos');

  const categories = ['Todos', 'Físico', 'Mental', 'Mindfulness', 'Respiração', 'Emocional'];

  const filteredTechniques = selectedCategory === 'Todos' 
    ? techniques 
    : techniques.filter(t => t.category === selectedCategory);

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Iniciante': return 'bg-green-100 text-green-800';
      case 'Intermediário': return 'bg-yellow-100 text-yellow-800';
      case 'Avançado': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-800 mb-4">
          Técnicas de Relaxamento
        </h2>
        <p className="text-lg text-gray-600">
          Descubra diferentes métodos para reduzir estresse e encontrar paz interior
        </p>
      </div>

      {/* Category Filter */}
      <div className="mb-8">
        <div className="flex flex-wrap gap-2 justify-center">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-full font-medium transition-all duration-200 ${
                selectedCategory === category
                  ? 'bg-indigo-600 text-white shadow-lg'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      {/* Techniques List */}
      <div className="space-y-4">
        {filteredTechniques.map((technique) => (
          <div key={technique.id} className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div 
              className="p-6 cursor-pointer hover:bg-gray-50 transition-colors duration-200"
              onClick={() => setExpandedTechnique(
                expandedTechnique === technique.id ? null : technique.id
              )}
            >
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h3 className="text-xl font-semibold text-gray-800">
                      {technique.title}
                    </h3>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(technique.difficulty)}`}>
                      {technique.difficulty}
                    </span>
                  </div>
                  <p className="text-gray-600 mb-3">{technique.description}</p>
                  <div className="flex items-center space-x-4 text-sm text-gray-500">
                    <div className="flex items-center space-x-1">
                      <Clock className="w-4 h-4" />
                      <span>{technique.duration}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Users className="w-4 h-4" />
                      <span>{technique.category}</span>
                    </div>
                  </div>
                </div>
                <div className="ml-4">
                  {expandedTechnique === technique.id ? (
                    <ChevronUp className="w-6 h-6 text-gray-400" />
                  ) : (
                    <ChevronDown className="w-6 h-6 text-gray-400" />
                  )}
                </div>
              </div>
            </div>

            {expandedTechnique === technique.id && (
              <div className="px-6 pb-6 border-t border-gray-100">
                <div className="grid md:grid-cols-2 gap-6 mt-6">
                  <div>
                    <h4 className="text-lg font-semibold text-gray-800 mb-3">
                      Passos para praticar
                    </h4>
                    <ol className="space-y-2">
                      {technique.steps.map((step, index) => (
                        <li key={index} className="flex items-start space-x-3">
                          <span className="flex-shrink-0 w-6 h-6 bg-indigo-600 text-white rounded-full flex items-center justify-center text-sm font-medium">
                            {index + 1}
                          </span>
                          <span className="text-gray-600">{step}</span>
                        </li>
                      ))}
                    </ol>
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-800 mb-3">
                      Benefícios
                    </h4>
                    <ul className="space-y-2">
                      {technique.benefits.map((benefit, index) => (
                        <li key={index} className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <span className="text-gray-600">{benefit}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Tips Section */}
      <div className="mt-12 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-8">
        <h3 className="text-2xl font-bold text-gray-800 mb-4">
          Dicas para uma prática eficaz
        </h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-semibold text-gray-800 mb-2">Ambiente</h4>
            <ul className="space-y-1 text-gray-600">
              <li>• Escolha um local silencioso</li>
              <li>• Mantenha temperatura confortável</li>
              <li>• Use roupas soltas</li>
              <li>• Desligue dispositivos eletrônicos</li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-gray-800 mb-2">Consistência</h4>
            <ul className="space-y-1 text-gray-600">
              <li>• Pratique no mesmo horário</li>
              <li>• Comece com sessões curtas</li>
              <li>• Seja paciente consigo mesmo</li>
              <li>• Mantenha regularidade</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}