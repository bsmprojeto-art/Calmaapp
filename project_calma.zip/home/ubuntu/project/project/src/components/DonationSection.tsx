import React, { useState } from 'react';
import { Heart, Copy, Check, Gift, Users, Sparkles } from 'lucide-react';

export default function DonationSection() {
  const [copied, setCopied] = useState(false);
  const pixKey = 'bsmprojeto@gmail.com';

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(pixKey);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = pixKey;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6">
      <div className="bg-gradient-to-br from-pink-50 via-purple-50 to-indigo-50 rounded-2xl sm:rounded-3xl shadow-2xl p-6 sm:p-8 lg:p-10 border border-white/30 relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-24 sm:w-32 h-24 sm:h-32 bg-gradient-to-br from-pink-200 to-purple-200 rounded-full opacity-20 -translate-y-12 sm:-translate-y-16 translate-x-12 sm:translate-x-16"></div>
        <div className="absolute bottom-0 left-0 w-16 sm:w-24 h-16 sm:h-24 bg-gradient-to-br from-indigo-200 to-blue-200 rounded-full opacity-20 translate-y-8 sm:translate-y-12 -translate-x-8 sm:-translate-x-12"></div>
        
        <div className="text-center relative z-10">
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full flex items-center justify-center shadow-xl">
              <Heart className="w-8 h-8 sm:w-10 sm:h-10 text-white fill-current animate-pulse" />
            </div>
          </div>
          
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-800 mb-4 tracking-tight">
            Espalhe a <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-600 to-purple-600">Calma</span>
          </h2>
          
          <p className="text-base sm:text-lg lg:text-xl text-gray-600 mb-6 sm:mb-8 leading-relaxed max-w-2xl mx-auto px-4">
            Se este app trouxe paz ao seu coração, considere ajudar a levar essa tranquilidade para mais pessoas que precisam.
          </p>

          {/* Destaque especial para doação */}
          <div className="bg-gradient-to-r from-pink-500 to-purple-600 rounded-2xl sm:rounded-3xl p-6 sm:p-8 mb-6 sm:mb-8 text-white shadow-2xl transform hover:scale-105 transition-all duration-300">
            <div className="flex items-center justify-center mb-4">
              <Gift className="w-8 h-8 sm:w-12 sm:h-12 mr-3" />
              <div className="text-left">
                <h3 className="text-xl sm:text-2xl lg:text-3xl font-bold">Apoie Este Projeto</h3>
                <p className="text-sm sm:text-base opacity-90">Sua doação mantém o app gratuito para todos</p>
              </div>
            </div>
            
            <div className="bg-white/20 backdrop-blur-sm rounded-xl p-4 sm:p-6">
              <div className="flex items-center justify-center mb-3">
                <img 
                  src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiByeD0iOCIgZmlsbD0iIzAwQzI1MyIvPgo8cGF0aCBkPSJNMTIgMjBIMjhNMjAgMTJWMjgiIHN0cm9rZT0id2hpdGUiIHN0cm9rZS13aWR0aD0iMyIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+Cjwvc3ZnPgo=" 
                  alt="PIX" 
                  className="w-8 h-8 sm:w-10 sm:h-10"
                />
              </div>
              
              <p className="text-base sm:text-lg font-semibold mb-3">Chave PIX:</p>
              
              <div className="bg-white rounded-lg p-3 sm:p-4 mb-4">
                <div className="flex flex-col sm:flex-row items-center gap-3">
                  <code className="text-sm sm:text-base font-mono text-gray-800 break-all text-center sm:text-left flex-1">
                    {pixKey}
                  </code>
                  <button
                    onClick={copyToClipboard}
                    className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg font-semibold transition-all duration-200 whitespace-nowrap ${
                      copied
                        ? 'bg-green-500 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {copied ? (
                      <>
                        <Check className="w-4 h-4" />
                        <span className="hidden sm:inline">Copiado!</span>
                        <span className="sm:hidden">✓</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4" />
                        <span className="hidden sm:inline">Copiar</span>
                        <span className="sm:hidden">📋</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
              
              <p className="text-sm opacity-90">
                💝 Qualquer valor faz a diferença e nos ajuda a manter este projeto vivo!
              </p>
            </div>
          </div>

          {/* Impact Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 mb-8 sm:mb-10">
            <div className="bg-white/70 backdrop-blur-sm rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-lg">
              <div className="flex items-center justify-center mb-3">
                <Users className="w-6 h-6 sm:w-8 sm:h-8 text-indigo-600" />
              </div>
              <div className="text-xl sm:text-2xl font-bold text-gray-800 mb-1">1000+</div>
              <div className="text-xs sm:text-sm text-gray-600">Pessoas já ajudadas</div>
            </div>
            
            <div className="bg-white/70 backdrop-blur-sm rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-lg">
              <div className="flex items-center justify-center mb-3">
                <Sparkles className="w-6 h-6 sm:w-8 sm:h-8 text-purple-600" />
              </div>
              <div className="text-xl sm:text-2xl font-bold text-gray-800 mb-1">5000+</div>
              <div className="text-xs sm:text-sm text-gray-600">Sessões de calma</div>
            </div>
            
            <div className="bg-white/70 backdrop-blur-sm rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-lg">
              <div className="flex items-center justify-center mb-3">
                <Gift className="w-6 h-6 sm:w-8 sm:h-8 text-pink-600" />
              </div>
              <div className="text-xl sm:text-2xl font-bold text-gray-800 mb-1">100%</div>
              <div className="text-xs sm:text-sm text-gray-600">Gratuito sempre</div>
            </div>
          </div>

          <div className="bg-white/80 backdrop-blur-sm rounded-xl sm:rounded-2xl p-6 sm:p-8 shadow-xl mb-6 sm:mb-8">
            <h3 className="text-xl sm:text-2xl font-semibold text-gray-800 mb-4">
              💝 Sua doação faz a diferença
            </h3>
            
            <p className="text-sm sm:text-base text-gray-600 mb-6 leading-relaxed">
              Cada contribuição, por menor que seja, nos ajuda a manter este projeto gratuito e desenvolver novas funcionalidades para apoiar mais pessoas em sua jornada de bem-estar mental.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-left">
              <ul className="space-y-2 text-gray-600 text-sm sm:text-base">
                <li>• Manter o app gratuito para todos</li>
                <li>• Desenvolver novas técnicas de relaxamento</li>
                <li>• Adicionar mais conteúdo ao livro</li>
              </ul>
              <ul className="space-y-2 text-gray-600 text-sm sm:text-base">
                <li>• Melhorar a experiência do usuário</li>
                <li>• Criar versões em outros idiomas</li>
                <li>• Apoiar pesquisas em bem-estar mental</li>
              </ul>
            </div>
          </div>

          <div className="text-center">
            <p className="text-sm sm:text-base text-gray-600 mb-4 italic">
              "A generosidade é uma forma de amor em ação. Quando doamos, não apenas ajudamos outros, mas também cultivamos nossa própria paz interior."
            </p>
            
            <div className="flex flex-wrap justify-center gap-2 sm:gap-4 text-xs sm:text-sm text-gray-500">
              <span className="flex items-center gap-1">
                <Heart className="w-4 h-4 text-pink-500" />
                Feito com amor
              </span>
              <span className="flex items-center gap-1">
                <Gift className="w-4 h-4 text-purple-500" />
                Sempre gratuito
              </span>
              <span className="flex items-center gap-1">
                <Users className="w-4 h-4 text-indigo-500" />
                Para toda comunidade
              </span>
            </div>
          </div>

          <div className="mt-6 sm:mt-8 p-4 sm:p-6 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl border border-indigo-200">
            <h4 className="text-base sm:text-lg font-semibold text-gray-800 mb-3">
              🌟 Como sua doação ajuda:
            </h4>
            <p className="text-sm sm:text-base text-gray-600 text-center">
              Cada real doado é investido diretamente no desenvolvimento e manutenção deste projeto, garantindo que ele permaneça gratuito e acessível para todos que buscam paz e bem-estar mental.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}