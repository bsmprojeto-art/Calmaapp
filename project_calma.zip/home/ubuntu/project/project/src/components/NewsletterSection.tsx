import React, { useState } from 'react';
import { Mail, Send } from 'lucide-react';
import { translations, type Language } from '../lib/translations';
import NewsletterModal from './NewsletterModal';

interface NewsletterSectionProps {
  language: Language;
}

export default function NewsletterSection({ language }: NewsletterSectionProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const t = translations[language];

  return (
    <>
      <section data-section="newsletter" className="py-16 bg-gradient-to-br from-green-50 to-teal-50">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className="bg-green-100 p-4 rounded-full w-20 h-20 mx-auto mb-6 flex items-center justify-center">
            <Mail className="text-green-600" size={40} />
          </div>
          
          <h2 className="text-3xl font-bold text-gray-800 mb-4">
            {t.newsletter?.title || 'Newsletter'}
          </h2>
          
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            {t.newsletter?.description || 'Receba dicas de mindfulness e bem-estar diretamente no seu e-mail'}
          </p>

          <div className="bg-white p-8 rounded-xl shadow-lg max-w-md mx-auto">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">
              Não perca nenhum artigo
            </h3>
            <p className="text-gray-600 mb-6">
              Inscreva-se na nossa newsletter e receba os novos artigos diretamente no seu e-mail.
            </p>
            
            <button
              onClick={() => setIsModalOpen(true)}
              className="w-full bg-gradient-to-r from-green-600 to-teal-600 text-white py-3 px-6 rounded-lg font-semibold hover:from-green-700 hover:to-teal-700 transition-all duration-200 flex items-center justify-center gap-2"
            >
              <Send size={20} />
              Inscrever-se na Newsletter
            </button>
          </div>

          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
            <div className="text-center">
              <div className="bg-green-100 p-3 rounded-full w-12 h-12 mx-auto mb-3 flex items-center justify-center">
                <span className="text-green-600 font-bold">📧</span>
              </div>
              <h4 className="font-semibold text-gray-800 mb-2">Conteúdo Exclusivo</h4>
              <p className="text-sm text-gray-600">Artigos e dicas que não estão no site</p>
            </div>
            
            <div className="text-center">
              <div className="bg-green-100 p-3 rounded-full w-12 h-12 mx-auto mb-3 flex items-center justify-center">
                <span className="text-green-600 font-bold">🎯</span>
              </div>
              <h4 className="font-semibold text-gray-800 mb-2">Sem Spam</h4>
              <p className="text-sm text-gray-600">Apenas conteúdo de qualidade, quando relevante</p>
            </div>
            
            <div className="text-center">
              <div className="bg-green-100 p-3 rounded-full w-12 h-12 mx-auto mb-3 flex items-center justify-center">
                <span className="text-green-600 font-bold">🔓</span>
              </div>
              <h4 className="font-semibold text-gray-800 mb-2">Cancele Quando Quiser</h4>
              <p className="text-sm text-gray-600">Fácil de cancelar a inscrição</p>
            </div>
          </div>
        </div>
      </section>

      <NewsletterModal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        language={language}
      />
    </>
  );
}

