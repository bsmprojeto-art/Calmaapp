import React, { useState } from 'react';
import { Share2, Heart, Users, MessageCircle, Mail, Copy, Star, Facebook, Twitter, Bookmark } from 'lucide-react';
import { translations, Language } from '../lib/translations';

interface SharingSectionProps {
  language: Language;
}

export default function SharingSection({ language }: SharingSectionProps) {
  const t = (key: string) => translations[language][key as keyof typeof translations[Language]] || key;
  const [copied, setCopied] = useState(false);

  const shareUrl = window.location.href;
  const shareText = t('shareText');

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy: ', err);
    }
  };

  const shareButtons = [
    {
      name: 'WhatsApp',
      icon: MessageCircle,
      url: `https://wa.me/?text=${encodeURIComponent(shareText + ' ' + shareUrl)}`,
      color: 'bg-green-500 hover:bg-green-600',
      textColor: 'text-white'
    },
    {
      name: 'Facebook',
      icon: Facebook,
      url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`,
      color: 'bg-blue-600 hover:bg-blue-700',
      textColor: 'text-white'
    },
    {
      name: 'Twitter',
      icon: Twitter,
      url: `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`,
      color: 'bg-sky-500 hover:bg-sky-600',
      textColor: 'text-white'
    },
    {
      name: 'Email',
      icon: Mail,
      url: `mailto:?subject=${encodeURIComponent(t('emailSubject'))}&body=${encodeURIComponent(shareText + '\n\n' + shareUrl)}`,
      color: 'bg-gray-600 hover:bg-gray-700',
      textColor: 'text-white'
    }
  ];

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center space-x-2">
          <Share2 className="w-8 h-8 text-indigo-600" />
          <h1 className="text-3xl font-bold text-gray-800">{t('shareTitle')}</h1>
        </div>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          {t('shareDescription')}
        </p>
      </div>

      {/* Quick Share Buttons */}
      <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
        <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
          <Star className="w-5 h-5 text-yellow-500 mr-2" />
          {t('quickShare')}
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {shareButtons.map((button) => (
            <a
              key={button.name}
              href={button.url}
              target="_blank"
              rel="noopener noreferrer"
              className={`${button.color} ${button.textColor} p-4 rounded-lg flex flex-col items-center space-y-2 transition-all duration-200 transform hover:scale-105 shadow-md`}
            >
              <button.icon className="w-6 h-6" />
              <span className="text-sm font-medium">{button.name}</span>
            </a>
          ))}
        </div>
      </div>

      {/* Copy Link Section */}
      <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-6 border border-indigo-100">
        <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
          <Copy className="w-5 h-5 text-indigo-600 mr-2" />
          {t('copyLink')}
        </h2>
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={shareUrl}
            readOnly
            className="flex-1 px-4 py-3 bg-white border border-gray-200 rounded-lg text-gray-700 text-sm"
          />
          <button
            onClick={handleCopyLink}
            className={`px-6 py-3 rounded-lg font-medium transition-all duration-200 ${
              copied
                ? 'bg-green-500 text-white'
                : 'bg-indigo-600 hover:bg-indigo-700 text-white'
            }`}
          >
            {copied ? t('copied') : t('copy')}
          </button>
        </div>
      </div>

      {/* Save to Favorites */}
      <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
        <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
          <Bookmark className="w-5 h-5 text-red-500 mr-2" />
          {t('saveToFavorites')}
        </h2>
        <div className="space-y-3 text-gray-600">
          <p>{t('favoriteInstructions')}</p>
          <div className="bg-gray-50 p-4 rounded-lg">
            <p className="text-sm">
              <strong>{t('desktop')}:</strong> {t('desktopInstructions')}
            </p>
            <p className="text-sm mt-2">
              <strong>{t('mobile')}:</strong> {t('mobileInstructions')}
            </p>
          </div>
        </div>
      </div>

      {/* Impact Stats */}
      <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-xl p-6 border border-green-100">
        <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
          <Heart className="w-5 h-5 text-red-500 mr-2" />
          {t('impactTitle')}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="text-3xl font-bold text-green-600">🧘‍♀️</div>
            <p className="text-sm text-gray-600 mt-2">{t('impactMeditation')}</p>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-blue-600">📚</div>
            <p className="text-sm text-gray-600 mt-2">{t('impactKnowledge')}</p>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-purple-600">🌱</div>
            <p className="text-sm text-gray-600 mt-2">{t('impactGrowth')}</p>
          </div>
        </div>
      </div>

      {/* Sharing Tips */}
      <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
        <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
          <Users className="w-5 h-5 text-indigo-600 mr-2" />
          {t('sharingTips')}
        </h2>
        <div className="space-y-3 text-gray-600">
          <div className="flex items-start space-x-3">
            <div className="w-2 h-2 bg-indigo-600 rounded-full mt-2 flex-shrink-0"></div>
            <p>{t('tip1')}</p>
          </div>
          <div className="flex items-start space-x-3">
            <div className="w-2 h-2 bg-indigo-600 rounded-full mt-2 flex-shrink-0"></div>
            <p>{t('tip2')}</p>
          </div>
          <div className="flex items-start space-x-3">
            <div className="w-2 h-2 bg-indigo-600 rounded-full mt-2 flex-shrink-0"></div>
            <p>{t('tip3')}</p>
          </div>
        </div>
      </div>
    </div>
  );
}