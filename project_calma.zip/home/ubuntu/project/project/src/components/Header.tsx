import React from 'react';
import { Brain, Wind, Heart, Moon, Home, Menu, X, BookOpen, Gift, Share2, Star, User, LogIn } from 'lucide-react';
import { useState } from 'react';
import LanguageSelector from './LanguageSelector';
import { translations, type Language, type TranslationKey } from '../lib/translations';

type Section = 'home' | 'meditation' | 'breathing' | 'techniques' | 'progress' | 'book' | 'donation' | 'sharing' | 'reviews' | 'practice' | 'blog' | 'auth';

interface HeaderProps {
  activeSection: Section;
  setActiveSection: (section: Section) => void;
  language: Language;
  setLanguage: (language: Language) => void;
  user?: any;
  onLogout?: () => void;
}

export default function Header({ activeSection, setActiveSection, language, setLanguage, user, onLogout }: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const t = translations[language];

  const getTranslation = (key: TranslationKey): string => {
    return t[key] || translations.pt[key];
  };

  const navItems = [
    { id: 'home' as Section, label: getTranslation('home'), icon: <Home className="w-4 h-4" /> },
    { id: 'meditation' as Section, label: getTranslation('meditation'), icon: <Brain className="w-4 h-4" /> },
    { id: 'breathing' as Section, label: getTranslation('breathing'), icon: <Wind className="w-4 h-4" /> },
    { id: 'techniques' as Section, label: getTranslation('techniques'), icon: <Heart className="w-4 h-4" /> },
    { id: 'progress' as Section, label: getTranslation('progress'), icon: <Moon className="w-4 h-4" /> },
    { id: 'book' as Section, label: getTranslation('book'), icon: <BookOpen className="w-4 h-4" /> },
    { id: 'practice' as Section, label: getTranslation('practice'), icon: <User className="w-4 h-4" /> },
    { id: 'blog' as Section, label: getTranslation('blog'), icon: <Star className="w-4 h-4" /> },
    { id: 'donation' as Section, label: getTranslation('donation'), icon: <Gift className="w-4 h-4" /> },
    { id: 'reviews' as Section, label: getTranslation('reviews'), icon: <Star className="w-4 h-4" /> },
    { id: 'sharing' as Section, label: getTranslation('sharing'), icon: <Share2 className="w-4 h-4" /> },
  ];

  const getShortLabel = (label: string) => {
    if (label.length <= 6) return label;
    return label.substring(0, 4) + '.';
  };

  return (
    <header className="bg-white/95 backdrop-blur-lg shadow-lg sticky top-0 z-50 border-b border-white/20">
      <div className="container mx-auto px-3 sm:px-4 lg:px-6">
        <div className="flex items-center justify-between h-14 sm:h-16">
          {/* Logo */}
          <div 
            onClick={() => setActiveSection('home')}
            className="flex items-center space-x-2 cursor-pointer flex-shrink-0"
          >
            <div className="w-8 h-8 sm:w-10 sm:h-10 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
              <Brain className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
            </div>
            <span className="text-lg sm:text-xl font-bold text-gray-800 tracking-tight">Calma</span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center justify-center flex-1 mx-4">
            <nav className="flex items-center space-x-1 xl:space-x-2 bg-gray-50/80 rounded-2xl p-1">
              {navItems.slice(0, 8).map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveSection(item.id)}
                  className={`flex items-center space-x-1 px-2 xl:px-3 py-2 rounded-xl transition-all duration-200 text-xs xl:text-sm hover:scale-105 whitespace-nowrap ${
                    activeSection === item.id
                      ? 'bg-white text-indigo-700 shadow-md border border-indigo-100'
                      : 'text-gray-600 hover:text-indigo-600 hover:bg-white/50'
                  }`}
                >
                  {item.icon}
                  <span className="font-medium hidden xl:inline">{item.label}</span>
                  <span className="font-medium xl:hidden">{getShortLabel(item.label)}</span>
                </button>
              ))}
            </nav>
          </div>

          {/* Right Side - Language, Auth, Menu */}
          <div className="flex items-center space-x-2 flex-shrink-0">
            {/* Language Selector */}
            <div className="hidden sm:block">
              <LanguageSelector currentLanguage={language} onLanguageChange={setLanguage} />
            </div>

            {/* Auth Button */}
            <div className="hidden lg:block">
              {user ? (
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-gray-600 max-w-20 truncate">{user.email}</span>
                  <button
                    onClick={onLogout}
                    className="px-3 py-2 text-sm bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors"
                  >
                    {getTranslation('logout')}
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setActiveSection('auth')}
                  className="flex items-center space-x-1 px-3 py-2 bg-indigo-100 text-indigo-700 rounded-lg hover:bg-indigo-200 transition-colors text-sm"
                >
                  <LogIn className="w-4 h-4" />
                  <span>{getTranslation('login')}</span>
                </button>
              )}
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="lg:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors duration-200"
            >
              {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="lg:hidden py-4 border-t border-gray-200/50">
            {/* Language Selector for Mobile */}
            <div className="sm:hidden mb-4 flex justify-center">
              <LanguageSelector currentLanguage={language} onLanguageChange={setLanguage} />
            </div>

            {/* Auth Section for Mobile */}
            <div className="mb-4 px-4">
              {user ? (
                <div className="flex items-center justify-between bg-gray-50 rounded-lg p-3">
                  <span className="text-sm text-gray-600 truncate">{user.email}</span>
                  <button
                    onClick={onLogout}
                    className="px-3 py-1 text-sm bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors"
                  >
                    {getTranslation('logout')}
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => {
                    setActiveSection('auth');
                    setIsMenuOpen(false);
                  }}
                  className="w-full flex items-center justify-center space-x-2 px-4 py-3 bg-indigo-100 text-indigo-700 rounded-lg hover:bg-indigo-200 transition-colors"
                >
                  <LogIn className="w-4 h-4" />
                  <span>{getTranslation('login')}</span>
                </button>
              )}
            </div>

            {/* Navigation Items */}
            <nav className="flex flex-col space-y-1 px-4">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveSection(item.id);
                    setIsMenuOpen(false);
                  }}
                  className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 text-sm hover:scale-[1.02] ${
                    activeSection === item.id
                      ? 'bg-indigo-100 text-indigo-700 shadow-lg border border-indigo-200'
                      : 'text-gray-600 hover:text-indigo-600 hover:bg-gray-50'
                  }`}
                >
                  {item.icon}
                  <span className="font-medium">{item.label}</span>
                </button>
              ))}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}

