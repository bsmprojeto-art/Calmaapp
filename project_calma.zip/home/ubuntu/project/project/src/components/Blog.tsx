import React, { useState, useEffect } from 'react';
import { BookOpen, Plus, Edit3, Calendar, User, Send, X, Eye } from 'lucide-react';
import { getBlogPosts, createBlogPost, isAdmin, type BlogPost } from '../lib/supabase';
import { translations, type Language } from '../lib/translations';

interface BlogProps {
  language: Language;
  user: any;
}

export default function Blog({ language, user }: BlogProps) {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [isUserAdmin, setIsUserAdmin] = useState(false);
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    content: ''
  });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const t = translations[language];

  useEffect(() => {
    loadPosts();
    checkAdminStatus();
  }, [user]);

  const loadPosts = async () => {
    try {
      const blogPosts = await getBlogPosts();
      setPosts(blogPosts);
    } catch (error) {
      console.error('Error loading posts:', error);
    } finally {
      setLoading(false);
    }
  };

  const checkAdminStatus = async () => {
    if (user) {
      const adminStatus = await isAdmin();
      setIsUserAdmin(adminStatus);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');

    try {
      const newPost = await createBlogPost(formData.title, formData.content);
      setPosts([newPost, ...posts]);
      setFormData({ title: '', content: '' });
      setShowForm(false);
    } catch (error: any) {
      setError(error.message || 'Erro ao criar post');
    } finally {
      setSubmitting(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const truncateContent = (content: string, maxLength: number = 200) => {
    if (content.length <= maxLength) return content;
    return content.substring(0, maxLength) + '...';
  };

  if (selectedPost) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="bg-white/90 backdrop-blur-sm rounded-2xl sm:rounded-3xl shadow-2xl p-6 sm:p-8 border border-white/20">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <button
              onClick={() => setSelectedPost(null)}
              className="flex items-center space-x-2 text-indigo-600 hover:text-indigo-700 transition-colors"
            >
              <X className="w-5 h-5" />
              <span>Voltar aos artigos</span>
            </button>
            <div className="flex items-center space-x-2 text-sm text-gray-500">
              <Calendar className="w-4 h-4" />
              <span>{formatDate(selectedPost.created_at)}</span>
            </div>
          </div>

          {/* Article */}
          <article className="prose prose-lg max-w-none">
            <h1 className="text-3xl sm:text-4xl font-bold text-gray-800 mb-6">
              {selectedPost.title}
            </h1>
            
            <div className="text-gray-700 leading-relaxed whitespace-pre-wrap">
              {selectedPost.content}
            </div>
          </article>

          {/* Author */}
          {selectedPost.author_email && (
            <div className="mt-8 pt-6 border-t border-gray-200">
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <User className="w-4 h-4" />
                <span>Por: {selectedPost.author_email}</span>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6">
      <div className="bg-white/90 backdrop-blur-sm rounded-2xl sm:rounded-3xl shadow-2xl p-6 sm:p-8 border border-white/20">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
            <BookOpen className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-4">
            {t.blogTitle}
          </h2>
          <p className="text-gray-600 text-lg">
            Artigos sobre mindfulness, bem-estar e crescimento pessoal
          </p>
        </div>

        {/* Admin Controls */}
        {isUserAdmin && (
          <div className="mb-8 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-2xl p-6 border border-indigo-100">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-1">Painel do Administrador</h3>
                <p className="text-gray-600 text-sm">Gerencie os artigos do blog</p>
              </div>
              <button
                onClick={() => setShowForm(!showForm)}
                className="flex items-center space-x-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-4 py-2 rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 transform hover:scale-105"
              >
                <Plus className="w-4 h-4" />
                <span>{t.addNewPost}</span>
              </button>
            </div>
          </div>
        )}

        {/* Add Post Form */}
        {showForm && isUserAdmin && (
          <div className="mb-8 bg-white rounded-2xl p-6 border border-gray-200 shadow-lg">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-800">Novo Artigo</h3>
              <button
                onClick={() => setShowForm(false)}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {error && (
              <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-red-700 text-sm">{error}</p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t.title}
                </label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200"
                  placeholder="Digite o título do artigo"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t.content}
                </label>
                <textarea
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                  rows={12}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200 resize-none"
                  placeholder="Escreva o conteúdo do artigo..."
                  required
                />
              </div>

              <div className="flex space-x-4">
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-3 px-4 rounded-lg font-semibold hover:from-indigo-700 hover:to-purple-700 focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-[1.02] flex items-center justify-center space-x-2"
                >
                  {submitting ? (
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>{t.publish}</span>
                    </>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="px-6 py-3 bg-gray-100 text-gray-700 rounded-lg font-semibold hover:bg-gray-200 transition-all duration-200"
                >
                  Cancelar
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Posts Grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="bg-gray-200 rounded-2xl h-64"></div>
              </div>
            ))}
          </div>
        ) : posts.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <BookOpen className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">{t.noArticles}</h3>
            <p className="text-gray-600">
              {isUserAdmin 
                ? 'Adicione o primeiro artigo clicando no botão acima.'
                : 'Novos artigos serão publicados em breve.'
              }
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {posts.map((post) => (
              <article
                key={post.id}
                className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-200 transform hover:scale-[1.02] cursor-pointer"
                onClick={() => setSelectedPost(post)}
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-2 text-sm text-gray-500">
                    <Calendar className="w-4 h-4" />
                    <span>{formatDate(post.created_at)}</span>
                  </div>
                  <div className="w-8 h-8 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center">
                    <Eye className="w-4 h-4 text-white" />
                  </div>
                </div>

                <h3 className="text-xl font-bold text-gray-800 mb-3 line-clamp-2">
                  {post.title}
                </h3>

                <p className="text-gray-600 text-sm leading-relaxed mb-4 line-clamp-3">
                  {truncateContent(post.content)}
                </p>

                <div className="flex items-center justify-between">
                  <button className="text-indigo-600 hover:text-indigo-700 font-medium text-sm transition-colors">
                    Ler artigo completo →
                  </button>
                  {post.author_email && (
                    <div className="flex items-center space-x-1 text-xs text-gray-500">
                      <User className="w-3 h-3" />
                      <span>Admin</span>
                    </div>
                  )}
                </div>
              </article>
            ))}
          </div>
        )}

        {/* Call to Action for Non-Admin Users */}
        {!user && (
          <div className="mt-12 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-2xl p-6 sm:p-8 border border-indigo-100 text-center">
            <div className="w-12 h-12 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center mx-auto mb-4">
              <Edit3 className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-800 mb-2">Quer contribuir?</h3>
            <p className="text-gray-600 mb-4">
              Se você tem experiência em mindfulness e gostaria de compartilhar seus conhecimentos, 
              entre em contato conosco.
            </p>
            <button 
              onClick={() => {
                const subject = encodeURIComponent('Contribuição para o Blog - App Calma');
                const body = encodeURIComponent('Olá,\n\nGostaria de contribuir com artigos para o blog do App Calma.\n\nMinha experiência em mindfulness:\n\nTemas que gostaria de abordar:\n\nObrigado!');
                window.open(`mailto:bsmprojeto@gmail.com?subject=${subject}&body=${body}`, '_blank');
              }}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 transform hover:scale-105"
            >
              Entrar em Contato
            </button>
          </div>
        )}

        {/* Newsletter CTA */}
        <div className="mt-12 bg-gradient-to-r from-emerald-50 to-teal-50 rounded-2xl p-6 sm:p-8 border border-emerald-100 text-center">
          <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center mx-auto mb-4">
            <Send className="w-6 h-6 text-white" />
          </div>
          <h3 className="text-xl font-bold text-gray-800 mb-2">Não perca nenhum artigo</h3>
          <p className="text-gray-600 mb-4">
            Inscreva-se na nossa newsletter e receba os novos artigos diretamente no seu e-mail.
          </p>
          <button 
            onClick={() => {
              // Scroll to newsletter section if it exists, or redirect to home with newsletter focus
              const newsletterSection = document.querySelector('[data-section="newsletter"]');
              if (newsletterSection) {
                newsletterSection.scrollIntoView({ behavior: 'smooth' });
              } else {
                // If newsletter section is not on this page, go to home and focus newsletter
                window.location.href = '/#newsletter';
              }
            }}
            className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-emerald-700 hover:to-teal-700 transition-all duration-200 transform hover:scale-105"
          >
            Inscrever-se na Newsletter
          </button>
        </div>
      </div>
    </div>
  );
}

