import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Volume2, VolumeX, Bell, Music } from 'lucide-react';

interface AmbientSound {
  id: string;
  name: string;
  generator: () => AudioBuffer | null;
}

interface MeditationTimerProps {
  onSessionComplete?: (sessionTime: number) => void;
}

export default function MeditationTimer({ onSessionComplete }: MeditationTimerProps) {
  const [duration, setDuration] = useState(5); // minutes
  const [timeLeft, setTimeLeft] = useState(duration * 60); // seconds
  const [isActive, setIsActive] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [ambientSoundEnabled, setAmbientSoundEnabled] = useState(false);
  const [bellSoundEnabled, setBellSoundEnabled] = useState(true);
  const [selectedSoundId, setSelectedSoundId] = useState<string>('white_noise');
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null);
  const [gainNode, setGainNode] = useState<GainNode | null>(null);
  const [sourceNode, setSourceNode] = useState<AudioBufferSourceNode | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // Initialize audio context
  useEffect(() => {
    const initAudio = () => {
      try {
        const context = new (window.AudioContext || (window as any).webkitAudioContext)();
        const gain = context.createGain();
        gain.connect(context.destination);
        gain.gain.value = 0.3;
        
        setAudioContext(context);
        setGainNode(gain);
      } catch (error) {
        console.warn('Audio context not supported:', error);
      }
    };

    initAudio();

    return () => {
      if (audioContext) {
        audioContext.close();
      }
    };
  }, []);

  // Generate white noise buffer
  const generateWhiteNoise = (): AudioBuffer | null => {
    if (!audioContext) return null;
    
    const bufferSize = audioContext.sampleRate * 2;
    const buffer = audioContext.createBuffer(1, bufferSize, audioContext.sampleRate);
    const output = buffer.getChannelData(0);
    
    for (let i = 0; i < bufferSize; i++) {
      output[i] = (Math.random() * 2 - 1) * 0.1;
    }
    
    return buffer;
  };

  // Generate pink noise buffer
  const generatePinkNoise = (): AudioBuffer | null => {
    if (!audioContext) return null;
    
    const bufferSize = audioContext.sampleRate * 2;
    const buffer = audioContext.createBuffer(1, bufferSize, audioContext.sampleRate);
    const output = buffer.getChannelData(0);
    
    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
    
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.96900 * b2 + white * 0.1538520;
      b3 = 0.86650 * b3 + white * 0.3104856;
      b4 = 0.55000 * b4 + white * 0.5329522;
      b5 = -0.7616 * b5 - white * 0.0168980;
      output[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.11;
      b6 = white * 0.115926;
    }
    
    return buffer;
  };

  // Generate brown noise buffer
  const generateBrownNoise = (): AudioBuffer | null => {
    if (!audioContext) return null;
    
    const bufferSize = audioContext.sampleRate * 2;
    const buffer = audioContext.createBuffer(1, bufferSize, audioContext.sampleRate);
    const output = buffer.getChannelData(0);
    
    let lastOut = 0;
    
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      output[i] = (lastOut + (0.02 * white)) / 1.02;
      lastOut = output[i];
      output[i] *= 3.5;
    }
    
    return buffer;
  };

  // Generate ocean waves buffer
  const generateOceanWaves = (): AudioBuffer | null => {
    if (!audioContext) return null;
    
    const bufferSize = audioContext.sampleRate * 4;
    const buffer = audioContext.createBuffer(1, bufferSize, audioContext.sampleRate);
    const output = buffer.getChannelData(0);
    
    for (let i = 0; i < bufferSize; i++) {
      const t = i / audioContext.sampleRate;
      const wave1 = Math.sin(2 * Math.PI * 0.1 * t) * 0.3;
      const wave2 = Math.sin(2 * Math.PI * 0.05 * t) * 0.2;
      const noise = (Math.random() * 2 - 1) * 0.1;
      output[i] = (wave1 + wave2 + noise) * 0.5;
    }
    
    return buffer;
  };

  // Available ambient sounds
  const availableSounds: AmbientSound[] = [
    {
      id: 'white_noise',
      name: 'Ruído Branco',
      generator: generateWhiteNoise
    },
    {
      id: 'pink_noise',
      name: 'Ruído Rosa',
      generator: generatePinkNoise
    },
    {
      id: 'brown_noise',
      name: 'Ruído Marrom',
      generator: generateBrownNoise
    },
    {
      id: 'ocean_waves',
      name: 'Ondas do Mar',
      generator: generateOceanWaves
    }
  ];

  // Start ambient sound
  const startAmbientSound = () => {
    if (!audioContext || !gainNode || !ambientSoundEnabled) return;

    // Stop current sound
    if (sourceNode) {
      sourceNode.stop();
      setSourceNode(null);
    }

    const selectedSound = availableSounds.find(s => s.id === selectedSoundId);
    if (!selectedSound) return;

    const buffer = selectedSound.generator();
    if (!buffer) return;

    const source = audioContext.createBufferSource();
    source.buffer = buffer;
    source.loop = true;
    source.connect(gainNode);
    source.start();
    
    setSourceNode(source);
  };

  // Stop ambient sound
  const stopAmbientSound = () => {
    if (sourceNode) {
      sourceNode.stop();
      setSourceNode(null);
    }
  };

  // Handle ambient sound toggle
  useEffect(() => {
    if (ambientSoundEnabled && isActive) {
      startAmbientSound();
    } else {
      stopAmbientSound();
    }
  }, [ambientSoundEnabled, isActive, selectedSoundId]);

  useEffect(() => {
    setTimeLeft(duration * 60);
  }, [duration]);

  // Bell notification
  const showBellNotification = () => {
    if (bellSoundEnabled) {
      // Create a simple bell sound
      if (audioContext) {
        const oscillator = audioContext.createOscillator();
        const bellGain = audioContext.createGain();
        
        oscillator.connect(bellGain);
        bellGain.connect(audioContext.destination);
        
        oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(400, audioContext.currentTime + 0.5);
        
        bellGain.gain.setValueAtTime(0.3, audioContext.currentTime);
        bellGain.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 1);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 1);
      }

      // Visual notification
      const notification = document.createElement('div');
      notification.innerHTML = '🔔 Sessão concluída! Bem-vindo de volta ao presente.';
      notification.style.cssText = `
        position: fixed; top: 20px; right: 20px; z-index: 1000;
        background: linear-gradient(135deg, #10b981, #059669);
        color: white; padding: 16px 24px; border-radius: 12px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        font-weight: 600; animation: slideIn 0.5s ease-out;
      `;
      document.body.appendChild(notification);
      setTimeout(() => {
        notification.remove();
      }, 4000);
    }
  };

  useEffect(() => {
    if (isActive && timeLeft > 0) {
      intervalRef.current = setInterval(() => {
        setTimeLeft((time) => {
          if (time <= 1) {
            setIsActive(false);
            setIsCompleted(true);
            showBellNotification();
            stopAmbientSound();
            // Call the progress callback with session duration in minutes
            if (onSessionComplete) {
              onSessionComplete(duration);
            }
            return 0;
          }
          return time - 1;
        });
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
      if (!isActive) {
        stopAmbientSound();
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isActive, timeLeft, bellSoundEnabled]);

  const toggleTimer = () => {
    if (audioContext && audioContext.state === 'suspended') {
      audioContext.resume();
    }
    setIsActive(!isActive);
    setIsCompleted(false);
  };

  const resetTimer = () => {
    setIsActive(false);
    setTimeLeft(duration * 60);
    setIsCompleted(false);
    stopAmbientSound();
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = ((duration * 60 - timeLeft) / (duration * 60)) * 100;

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6">
      <div className="bg-white/90 backdrop-blur-sm rounded-2xl sm:rounded-3xl shadow-2xl p-6 sm:p-8 lg:p-10 border border-white/20">
        <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-center text-gray-800 mb-6 sm:mb-8 lg:mb-10 tracking-tight">
          Meditação Guiada
        </h2>

        {/* Duration Selection */}
        <div className="mb-6 sm:mb-8 lg:mb-10">
          <label className="block text-base sm:text-lg font-semibold text-gray-700 mb-4 sm:mb-6">
            Duração da sessão
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
            {[5, 10, 15, 20].map((min) => (
              <button
                key={min}
                onClick={() => setDuration(min)}
                disabled={isActive}
                className={`py-3 sm:py-4 px-4 sm:px-6 rounded-xl sm:rounded-2xl font-bold transition-all duration-300 transform hover:scale-105 text-sm sm:text-base ${
                  duration === min
                    ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-xl'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200 shadow-md'
                } ${isActive ? 'opacity-50 cursor-not-allowed transform-none' : ''}`}
              >
                {min} min
              </button>
            ))}
          </div>
        </div>

        {/* Timer Display */}
        <div className="relative mb-6 sm:mb-8 lg:mb-10">
          <div className="w-64 h-64 sm:w-80 sm:h-80 mx-auto relative">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="45"
                stroke="currentColor"
                strokeWidth="3"
                fill="none"
                className="text-gray-200 drop-shadow-sm"
              />
              <circle
                cx="50"
                cy="50"
                r="45"
                stroke="currentColor"
                strokeWidth="3"
                fill="none"
                strokeDasharray={`${2 * Math.PI * 45}`}
                strokeDashoffset={`${2 * Math.PI * 45 * (1 - progress / 100)}`}
                className="text-indigo-600 transition-all duration-1000 ease-linear drop-shadow-lg"
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-800 mb-2 sm:mb-3 tracking-tight">
                  {formatTime(timeLeft)}
                </div>
                {isCompleted && (
                  <div className="text-green-600 font-bold text-sm sm:text-base lg:text-lg flex items-center justify-center gap-2">
                    <Bell className="w-4 h-4 sm:w-5 sm:h-5" />
                    Concluído! 🎉
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="flex justify-center space-x-3 sm:space-x-4 mb-4 sm:mb-6">
          <button
            onClick={toggleTimer}
            className="flex items-center justify-center w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-full hover:from-indigo-700 hover:to-purple-700 transition-all duration-300 shadow-xl transform hover:scale-110"
          >
            {isActive ? <Pause className="w-6 h-6 sm:w-8 sm:h-8 lg:w-10 lg:h-10" /> : <Play className="w-6 h-6 sm:w-8 sm:h-8 lg:w-10 lg:h-10 ml-1" />}
          </button>
          <button
            onClick={resetTimer}
            className="flex items-center justify-center w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-r from-gray-600 to-gray-700 text-white rounded-full hover:from-gray-700 hover:to-gray-800 transition-all duration-300 shadow-xl transform hover:scale-110"
          >
            <RotateCcw className="w-6 h-6 sm:w-8 sm:h-8 lg:w-10 lg:h-10" />
          </button>
          <button
            onClick={() => setAmbientSoundEnabled(!ambientSoundEnabled)}
            className={`flex items-center justify-center w-16 h-16 sm:w-20 sm:h-20 text-white rounded-full transition-all duration-300 shadow-xl transform hover:scale-110 ${
              ambientSoundEnabled 
                ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700' 
                : 'bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700'
            }`}
          >
            {ambientSoundEnabled ? <Music className="w-6 h-6 sm:w-8 sm:h-8 lg:w-10 lg:h-10" /> : <VolumeX className="w-6 h-6 sm:w-8 sm:h-8 lg:w-10 lg:h-10" />}
          </button>
          <button
            onClick={() => setBellSoundEnabled(!bellSoundEnabled)}
            className={`flex items-center justify-center w-16 h-16 sm:w-20 sm:h-20 text-white rounded-full transition-all duration-300 shadow-xl transform hover:scale-110 ${
              bellSoundEnabled 
                ? 'bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600' 
                : 'bg-gradient-to-r from-gray-500 to-gray-600 hover:from-gray-600 hover:to-gray-700'
            }`}
          >
            <Bell className="w-6 h-6 sm:w-8 sm:h-8 lg:w-10 lg:h-10" />
          </button>
        </div>

        {/* Sound Controls Info */}
        <div className="text-center mb-4 sm:mb-6 text-xs sm:text-sm text-gray-600">
          <div className="flex flex-col sm:flex-row items-center justify-center gap-2 sm:gap-4 mb-3">
            <span className="flex items-center gap-1">
              <Music className="w-4 h-4" />
              Som ambiente
            </span>
            <span className="flex items-center gap-1">
              <Bell className="w-4 h-4" />
              Notificação final
            </span>
          </div>
          
          {/* Sound Selection */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-2">
            <label className="text-xs text-gray-500">Som ambiente:</label>
            <select
              value={selectedSoundId}
              onChange={(e) => setSelectedSoundId(e.target.value)}
              disabled={isActive}
              className="text-xs bg-gray-50 border border-gray-200 rounded-lg px-2 py-1 focus:outline-none focus:ring-1 focus:ring-emerald-500 disabled:opacity-50"
            >
              {availableSounds.map((sound) => (
                <option key={sound.id} value={sound.id}>
                  {sound.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Meditation Guide */}
        <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl sm:rounded-2xl p-6 sm:p-8 border border-indigo-100">
          <h3 className="text-xl sm:text-2xl font-bold text-gray-800 mb-4 sm:mb-6">
            Guia de Meditação
          </h3>
          <div className="space-y-2 sm:space-y-3 text-gray-700 text-sm sm:text-base lg:text-lg">
            <p className="flex items-center gap-3">
              <span className="w-2 h-2 bg-indigo-500 rounded-full"></span>
              Encontre uma posição confortável
            </p>
            <p className="flex items-center gap-3">
              <span className="w-2 h-2 bg-indigo-500 rounded-full"></span>
              Feche os olhos suavemente
            </p>
            <p className="flex items-center gap-3">
              <span className="w-2 h-2 bg-indigo-500 rounded-full"></span>
              Respire naturalmente
            </p>
            <p className="flex items-center gap-3">
              <span className="w-2 h-2 bg-indigo-500 rounded-full"></span>
              Observe seus pensamentos sem julgamento
            </p>
            <p className="flex items-center gap-3">
              <span className="w-2 h-2 bg-indigo-500 rounded-full"></span>
              Retorne o foco à respiração quando necessário
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

