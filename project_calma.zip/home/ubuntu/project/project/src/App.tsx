import React, { useState, useEffect } from 'react';
import { Brain, Heart, Wind, Moon, Sun, Play, Pause, RotateCcw, BookOpen, Star, Gift, Share2, User, Newspaper } from 'lucide-react';
import { translations, type Language, type TranslationKey } from './lib/translations';
import { supabase, getCurrentUser, updateUserProgress } from './lib/supabase';
import Header from './components/Header';
import MeditationTimer from './components/MeditationTimer';
import BreathingExercise from './components/BreathingExercise';
import RelaxationTechniques from './components/RelaxationTechniques';
import DailyQuote from './components/DailyQuote';
import ProgressTracker from './components/ProgressTracker';
import BookReader from './components/BookReader';
import DonationSection from './components/DonationSection';
import SharingSection from './components/SharingSection';
import ReviewsSection from './components/ReviewsSection';
import AuthSection from './components/AuthSection';
import ProgressSection from './components/ProgressSection';
import NewsletterSection from './components/NewsletterSection';
import Practice from './components/Practice';
import Blog from './components/Blog';

type Section = 'home' | 'meditation' | 'breathing' | 'techniques' | 'progress' | 'book' | 'donation' | 'sharing' | 'reviews' | 'auth' | 'practice' | 'blog' | 'newsletter';

function App() {
  const [activeSection, setActiveSection] = useState<Section>('home');
  const [language, setLanguage] = useState<Language>('pt');
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for existing session
    getCurrentUser().then(user => {
      setUser(user);
      setLoading(false);
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setUser(session?.user ?? null);
        if (event === 'SIGNED_IN' && session?.user) {
          setActiveSection('home');
        }
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setActiveSection('home');
  };

  const handleAuthSuccess = (user: any) => {
    setUser(user);
    setActiveSection('home');
  };

  const handleMeditationComplete = async (sessionTime: number) => {
    if (user) {
      await updateUserProgress(user.id, sessionTime);
    }
  };

  const renderSection = () => {
    switch (activeSection) {
      case 'meditation':
        return <MeditationTimer onSessionComplete={handleMeditationComplete} />;
      case 'breathing':
        return <BreathingExercise />;
      case 'techniques':
        return <RelaxationTechniques />;
      case 'progress':
        return user ? (
          <ProgressSection language={language} user={user} />
        ) : (
          <AuthSection language={language} onAuthSuccess={handleAuthSuccess} />
        );
      case 'book':
        return <BookReader />;
      case 'donation':
        return <DonationSection />;
      case 'sharing':
        return <SharingSection language={language} />;
      case 'reviews':
        return <ReviewsSection />;
      case 'auth':
        return <AuthSection language={language} onAuthSuccess={handleAuthSuccess} />;
      case 'practice':
        return <Practice language={language} />;
      case 'blog':
        return <Blog language={language} user={user} />;
      case 'newsletter':
        return <NewsletterSection language={language} />;
      default:
        return <HomeSection setActiveSection={setActiveSection} language={language} user={user} />;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
            <Brain className="w-8 h-8 text-white animate-pulse" />
          </div>
          <h2 className="text-xl font-bold text-gray-800">Carregando...</h2>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      <Header 
        activeSection={activeSection} 
        setActiveSection={setActiveSection}
        language={language}
        setLanguage={setLanguage}
        user={user}
        onLogout={handleLogout}
      />
      <main className="container mx-auto py-4 sm:py-6 lg:py-8">
        {renderSection()}
      </main>
    </div>
  );
}

function HomeSection({ 
  setActiveSection, 
  language,
  user
}: { 
  setActiveSection: (section: Section) => void;
  language: Language;
  user: any;
}) {
  const t = translations[language];

  const getTranslation = (key: TranslationKey): string => {
    return t[key] || translations.pt[key];
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-8 sm:mb-12">
        <h1 className="text-3xl sm:text-4xl lg:text-6xl font-bold text-gray-800 mb-4 sm:mb-6 tracking-tight">
          {getTranslation('welcomeTitle')} <span className="text-indigo-600">Calma</span>
        </h1>
        <p className="text-base sm:text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed px-4">
          {getTranslation('welcomeSubtitle')}
        </p>
        {user && (
          <div className="mt-4 inline-flex items-center space-x-2 bg-green-100 text-green-800 px-4 py-2 rounded-full text-sm font-medium">
            <span>👋</span>
            <span>Bem-vindo de volta, {user.email?.split('@')[0]}!</span>
          </div>
        )}
      </div>

      <DailyQuote />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6 mb-8 sm:mb-12">
        <FeatureCard
          icon={<Brain className="w-8 h-8" />}
          title={getTranslation('guidedMeditation')}
          description={getTranslation('guidedMeditationDesc')}
          onClick={() => setActiveSection('meditation')}
          gradient="from-purple-500 to-indigo-600"
        />
        <FeatureCard
          icon={<Wind className="w-8 h-8" />}
          title={getTranslation('breathingExercises')}
          description={getTranslation('breathingExercisesDesc')}
          onClick={() => setActiveSection('breathing')}
          gradient="from-blue-500 to-cyan-600"
        />
        <FeatureCard
          icon={<Heart className="w-8 h-8" />}
          title={getTranslation('relaxationTechniques')}
          description={getTranslation('relaxationTechniquesDesc')}
          onClick={() => setActiveSection('techniques')}
          gradient="from-pink-500 to-rose-600"
        />
        <FeatureCard
          icon={<Moon className="w-8 h-8" />}
          title={getTranslation('trackProgress')}
          description={getTranslation('trackProgressDesc')}
          onClick={() => setActiveSection('progress')}
          gradient="from-indigo-500 to-purple-600"
          requiresAuth={true}
          user={user}
        />
        <FeatureCard
          icon={<BookOpen className="w-8 h-8" />}
          title={getTranslation('readBook')}
          description={getTranslation('readBookDesc')}
          onClick={() => setActiveSection('book')}
          gradient="from-emerald-500 to-teal-600"
        />
        <FeatureCard
          icon={<User className="w-8 h-8" />}
          title={getTranslation('practice')}
          description={getTranslation('practiceDescription')}
          onClick={() => setActiveSection('practice')}
          gradient="from-pink-500 to-rose-600"
        />
        <FeatureCard
          icon={<Star className="w-8 h-8" />}
          title={getTranslation('blog')}
          description="Artigos sobre mindfulness e bem-estar"
          onClick={() => setActiveSection('blog')}
          gradient="from-indigo-500 to-purple-600"
        />
        <FeatureCard
          icon={<Newspaper className="w-8 h-8" />}
          title={getTranslation('newsletterTitle')}
          description={getTranslation('newsletterDescription')}
          onClick={() => setActiveSection('newsletter')}
          gradient="from-emerald-500 to-teal-600"
        />
        <FeatureCard
          icon={<Gift className="w-8 h-8" />}
          title={getTranslation('supportProject')}
          description={getTranslation('supportProjectDesc')}
          onClick={() => setActiveSection('donation')}
          gradient="from-pink-500 to-purple-600"
        />
        <FeatureCard
          icon={<Star className="w-8 h-8" />}
          title={getTranslation('communityReviews')}
          description={getTranslation('communityReviewsDesc')}
          onClick={() => setActiveSection('reviews')}
          gradient="from-yellow-500 to-orange-600"
        />
        <FeatureCard
          icon={<Share2 className="w-8 h-8" />}
          title={getTranslation('shareApp')}
          description={getTranslation('shareAppDesc')}
          onClick={() => setActiveSection('sharing')}
          gradient="from-emerald-500 to-cyan-600"
          featured={true}
        />
      </div>

      <div className="bg-white/80 backdrop-blur-sm rounded-2xl sm:rounded-3xl shadow-2xl p-6 sm:p-8 lg:p-10 mb-8 border border-white/20">
        <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-800 mb-6 sm:mb-8 text-center">
          {getTranslation('whyMindfulness')}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8 lg:gap-10">
          <BenefitCard
            title={getTranslation('reducesStress')}
            description={getTranslation('reducesStressDesc')}
            icon="🧘‍♀️"
          />
          <BenefitCard
            title={getTranslation('improvesFocus')}
            description={getTranslation('improvesFocusDesc')}
            icon="🎯"
          />
          <BenefitCard
            title={getTranslation('sleepQuality')}
            description={getTranslation('sleepQualityDesc')}
            icon="😴"
          />
        </div>
      </div>
    </div>
  );
}

function FeatureCard({ 
  icon, 
  title, 
  description, 
  onClick, 
  gradient,
  featured = false,
  requiresAuth = false,
  user = null
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
  onClick: () => void;
  gradient: string;
  featured?: boolean;
  requiresAuth?: boolean;
  user?: any;
}) {
  const handleClick = () => {
    if (requiresAuth && !user) {
      // Redirect to auth if login required
      onClick(); // This will still work as the component will show auth form
    } else {
      onClick();
    }
  };

  return (
    <div className="relative">
      <div 
        onClick={handleClick}
        className={`bg-white/90 backdrop-blur-sm rounded-xl sm:rounded-2xl shadow-xl p-4 sm:p-6 cursor-pointer transform hover:scale-105 transition-all duration-300 hover:shadow-2xl group border relative overflow-hidden ${
          featured 
            ? 'border-emerald-300 ring-2 ring-emerald-200 bg-gradient-to-br from-emerald-50 to-cyan-50 shadow-emerald-200/50' 
            : 'border-white/30'
        }`}
      >
        {featured && (
          <div className="absolute -top-2 -right-2 bg-gradient-to-r from-emerald-500 to-cyan-600 text-white text-xs font-bold px-3 py-1 rounded-full shadow-lg animate-pulse">
            ⭐ Destaque
          </div>
        )}
        {requiresAuth && !user && (
          <div className="absolute -top-1 -left-1 bg-gradient-to-r from-indigo-500 to-purple-600 text-white text-xs font-bold px-2 py-1 rounded-full shadow-lg">
            🔒 Login
          </div>
        )}
        <div className={`w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-r ${gradient} rounded-xl sm:rounded-2xl flex items-center justify-center text-white mb-3 sm:mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg mx-auto sm:mx-0`}>
          {icon}
        </div>
        <h3 className="text-lg sm:text-xl font-bold text-gray-800 mb-2 sm:mb-3 text-center sm:text-left">{title}</h3>
        <p className="text-sm sm:text-base text-gray-600 leading-relaxed text-center sm:text-left">{description}</p>
      </div>
    </div>
  );
}

function BenefitCard({ title, description, icon }: {
  title: string;
  description: string;
  icon: string;
}) {
  return (
    <div className="text-center group p-4 rounded-xl hover:bg-white/50 transition-all duration-300">
      <div className="text-3xl sm:text-4xl lg:text-5xl mb-4 sm:mb-6 transform group-hover:scale-110 transition-transform duration-300">{icon}</div>
      <h3 className="text-xl sm:text-2xl font-bold text-gray-800 mb-3 sm:mb-4">{title}</h3>
      <p className="text-sm sm:text-base text-gray-600 leading-relaxed">{description}</p>
    </div>
  );
}

export default App;

